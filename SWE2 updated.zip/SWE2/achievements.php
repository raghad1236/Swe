<?php
// 1. Start session first
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Set timezone to ensure correct date comparisons for streaks
date_default_timezone_set('Asia/Riyadh');

// =======================================================
// 1.5. DATABASE CONNECTION LOGIC (MOVED FROM db_connect.php)
// =======================================================
// Configuration for the database connection - UPDATE THESE
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root'); // CHANGE THIS to your database username
define('DB_PASSWORD', 'root'); // CHANGE THIS to your database password
define('DB_NAME', 'PrepWiseDB'); 


function connect_db() {
    // Suppress warnings during connection attempt
    $conn = @new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

    // Check connection
    if ($conn->connect_error) {
        // Log the error internally, show a friendly message externally
        error_log("Connection failed: " . $conn->connect_error);
        throw new Exception("Database connection failed. Check configuration.");
    }
    
    // Set character set for proper data handling
    $conn->set_charset("utf8mb4");

    return $conn;
}
// =======================================================
// END DATABASE CONNECTION LOGIC
// =======================================================


// 2. Include necessary files with error checking
if (!file_exists('Auth.php') || !file_exists('AchievementLogic.php')) {
    // If files are missing, halt execution and display an error.
    die('<div style="background:#FEE2E2; border:1px solid #FECACA; padding:20px; color:#DC2626; margin:20px; border-radius:8px;">
        <h2 style="margin-top:0;">Dependency Error</h2>
        <p>Required PHP files (Auth.php or AchievementLogic.php) are missing. Please ensure all project files are present.</p>
    </div>');
}

require_once 'Auth.php';
require_once 'AchievementLogic.php';

// Auth::getStudentId() handles redirection if the user is not logged in.
$studentId = Auth::getStudentId();
$studentName = Auth::getStudentName(); // Fetching the logged-in user's name

// 3. Initialize the logic class and fetch achievements
try {
    // ESTABLISH CONNECTION HERE
    $conn = connect_db();
    
    // Pass the established connection object to the AchievementLogic constructor
    $logic = new AchievementLogic($studentId, $conn);
    $allAchievements = $logic->getUserAchievements();
    
    // --- NEW: FILTER TO SHOW ONLY UNLOCKED BADGES ---
    $achievements = array_filter($allAchievements, function($a) {
        return $a['unlocked'];
    });
    
    // Close connection after fetching data
    $conn->close();

} catch (Exception $e) {
    // Display a database connection error gracefully
    $dbError = '<div style="background:#FEE2E2; border:1px solid #FECACA; padding:20px; color:#DC2626; margin:20px; border-radius:8px;">
        <h2 style="margin-top:0;">Database Connection Error</h2>
        <p>Could not connect to the database or retrieve achievements. Please check your credentials in the PHP section of this file.</p>
        <p style="font-size: 0.8em; color: #EF4444;">Detail: ' . htmlspecialchars($e->getMessage()) . '</p>
    </div>';
    $achievements = []; // Ensure the foreach loop below doesn't crash
    if (isset($conn) && $conn instanceof mysqli) {
        $conn->close();
    }
}


// 4. Handle popup notification (This logic should ideally be in homepage.php but is kept here for reference)
$showPopup = false; 
$unlockedBadgeName = "New Badge"; 

// We keep this block to clear any pending popup data if the user lands here directly
if (isset($_SESSION['new_badge_pop'])) {
    $showPopup = true;
    $unlockedBadgeName = $_SESSION['new_badge_pop']['name'] ?? "New Badge";
    // Clear the session variable immediately after reading it
    unset($_SESSION['new_badge_pop']); 
}

// NOTE: The logic for setting the 'new_badge_pop' session variable happens in update_tasks.php.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>PrepWise • Achievements</title>
    <link rel="stylesheet" href="style.css" />
    <style>
        /* Optional: CSS for the badge card (You should ensure these are in style.css or embedded here) */
        .achievements-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }

        .achievement-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 20px;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0,0,0,0.05);
            position: relative;
        }

        .achievement-card img {
            width: 80px;
            height: 80px;
            margin-bottom: 10px;
            filter: grayscale(0%); /* Ensure unlocked badges are colorful */
        }
        
        .achievement-card h3 {
            margin: 0 0 5px 0;
            color: var(--text);
            font-size: 1.2em;
        }

        .achievement-card p {
            color: var(--muted);
            font-size: 0.9em;
        }

        .status-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            padding: 4px 8px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 700;
            background: var(--ok-bg);
            color: var(--ok-ink);
        }
    </style>
</head>
<body>

    <header class="header">
        <div class="container nav">
            <a href="homepage.php" class="brand">
                <img src="PrepWiseLogo.png" alt="PrepWise Logo" class="logo-img" style="height:52px; width:52px;">
                PrepWise
            </a>
            <nav>
                <a href="homepage.php">Home</a>
                <a href="plan.php">Plan</a>
                <a href="Pomodoro.php">Pomodoro</a>
                <a href="achievements.php" aria-current="page">Achievements</a>
                <a href="profile.php">Profile</a>
                <a href="logout.php">Logout</a>
            </nav>
        </div>
    </header>

    <main class="container">
        <?php if (isset($dbError)): ?>
            <?php echo $dbError; ?>
        <?php endif; ?>

        <?php if ($showPopup): ?>
        <div class="popup" style="background:#EEF2FF; border:1px solid #C7D2FE; padding:15px; border-radius:8px; margin-bottom: 20px;">
            🎉 Congratulations<?php echo $studentName ? ", " . htmlspecialchars($studentName) : ""; ?>! You unlocked a new badge: <strong>“<?php echo htmlspecialchars($unlockedBadgeName); ?>”</strong>!
        </div>
        <?php endif; ?>

        <section class="achievements-section">
            <h1 style="text-align:center; color:var(--brand); margin-bottom:1em;">Your Earned Achievements</h1>
            <p style="text-align:center; color:var(--muted); max-width:600px; margin:0 auto;">
                These are your earned milestones that keep you motivated and consistent throughout your study journey.
            </p>

            <div class="achievements-grid">
                <?php 
                // Only display achievements if there was no fatal database error and we have unlocked badges
                if (empty($dbError) && !empty($achievements)): 
                    foreach ($achievements as $achievement): 
                        // Since we filtered the array, all remaining badges are unlocked
                ?>
                    <div class="achievement-card unlocked">
                        <span class="status-badge">EARNED</span>
                        <img src="<?php echo htmlspecialchars($achievement['icon']); ?>" alt="<?php echo htmlspecialchars($achievement['name']); ?>">
                        <h3><?php echo htmlspecialchars($achievement['name']); ?></h3>
                        <p><?php echo htmlspecialchars($achievement['desc']); ?></p>
                    </div>
                <?php endforeach; ?>
                <?php else: ?>
                    <p style="grid-column: 1 / -1; text-align: center; color: var(--muted); padding: 2em; background: var(--brand-ghost); border-radius: 8px;">
                        Keep studying! No badges unlocked yet. Complete tasks and Pomodoro sessions to earn your first badges!
                    </p>
                <?php endif; ?>
            </div>
            
            </section>
    </main>

    <footer>
        <div class="footer-container">
            <div class="copyright">© 2025 PrepWise</div>

            <div class="logo">
                <img src="PrepWiseLogo.png" alt="PrepWise logo">
                <p class="textfooter">Smart study planner for students.</p>
            </div>

            <div class="social-media">
                <h3>Follow us</h3>
                <p><i>in</i> LinkedIn</p>
                <p><i>t</i> Twitter/X</p>
                <p><i>ig</i> Instagram</p>
            </div>

            <div class="contact-us">
                <h3>Contact</h3>
                <p><i>@</i> <a href="mailto:support@prepwise.app">support@prepwise.app</a></p>
                <p><i>☎</i> +966-555-000-000</p>
            </div>
            
        </div>
    </footer>

</body>
</html>