<?php

class AchievementLogic {
    private $conn;
    private $studentId;

    // MODIFIED CONSTRUCTOR: Accepts the mysqli connection object ($conn)
    // The main page (achievements.php) is responsible for creating and passing this object.
    public function __construct(int $studentId, mysqli $conn) {
        $this->conn = $conn;
        $this->studentId = $studentId;
    }

    // The __destruct() method has been removed because the connection is managed 
    // and closed by the main page (achievements.php) after the logic is executed.

    /**
     * Defines all possible achievements and their criteria.
     * The PHP logic will check if the user meets the criteria for each.
     */
    private function getAllAchievements(): array {
        return [
            // Achievement 1: First Task Done (Renamed for clarity, using chapter_status)
            'first_task' => [
                'name' => 'First Chapter Done',
                'desc' => 'Completed your very first chapter! Great start 🎯',
                'icon' => 'https://cdn-icons-png.flaticon.com/512/190/190411.png',
                'check_method' => 'checkFirstTaskDone'
            ],
            // Achievement 2: Chapter Master (Completing 5+ chapters)
            'chapter_master' => [
                'name' => 'Chapter Master',
                'desc' => 'You\'ve mastered 5 or more chapters. Keep going!',
                'icon' => 'https://cdn-icons-png.flaticon.com/512/3468/3468371.png',
                'check_method' => 'checkChapterMaster'
            ],
            // Achievement 3: Chapter 10 Achieved (NEW)
            'chapter_ten' => [
                'name' => 'Chapter 10 Achieved',
                'desc' => 'Reached double digits! You have completed 10 chapters.',
                'icon' => 'https://cdn-icons-png.flaticon.com/512/2610/2610058.png',
                'check_method' => 'checkChapterTenAchieved'
            ],
            // Achievement 4: Diverse Learner (NEW)
            'diverse_learner' => [
                'name' => 'Diverse Learner',
                'desc' => 'Completed chapters in 3 or more different subjects.',
                'icon' => 'https://cdn-icons-png.flaticon.com/512/3201/3201460.png',
                'check_method' => 'checkDiverseLearner'
            ],
            // Achievement 5: 3-Day Streak (Uses daily_plan table)
            'three_day_streak' => [
                'name' => '3-Day Streak',
                'desc' => 'Stayed consistent for three consecutive days 🔥',
                'icon' => 'https://cdn-icons-png.flaticon.com/512/9290/9290720.png',
                'check_method' => 'checkThreeDayStreak'
            ],
            // Achievement 6: Pomodoro Starter (Based on pomodoro_session table)
            'pomodoro_starter' => [
                'name' => 'Pomodoro Starter',
                'desc' => 'Completed your first study session.',
                'icon' => 'https://cdn-icons-png.flaticon.com/512/1360/1360877.png',
                'check_method' => 'checkPomodoroStarter'
            ]
        ];
    }

    /**
     * Checks if the student has completed at least one chapter (from chapter_status).
     */
    private function checkFirstTaskDone(): bool {
        $stmt = $this->conn->prepare("SELECT COUNT(*) FROM chapter_status WHERE student_id = ? AND completed = 1");
        $stmt->bind_param("i", $this->studentId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_row();
        return $result[0] > 0;
    }

    /**
     * Checks if the student has completed 5 or more chapters (from chapter_status).
     */
    private function checkChapterMaster(): bool {
        $stmt = $this->conn->prepare("SELECT COUNT(*) FROM chapter_status WHERE student_id = ? AND completed = 1");
        $stmt->bind_param("i", $this->studentId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_row();
        return $result[0] >= 5;
    }

    /**
     * Checks if the student has completed 10 or more chapters (from chapter_status).
     */
    private function checkChapterTenAchieved(): bool {
        $stmt = $this->conn->prepare("SELECT COUNT(*) FROM chapter_status WHERE student_id = ? AND completed = 1");
        $stmt->bind_param("i", $this->studentId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_row();
        return $result[0] >= 10; 
    }

    /**
     * Checks if the student has completed chapters in 3 or more unique subjects (from chapter_status).
     */
    private function checkDiverseLearner(): bool {
        $stmt = $this->conn->prepare("SELECT COUNT(DISTINCT subject_name) FROM chapter_status WHERE student_id = ? AND completed = 1");
        $stmt->bind_param("i", $this->studentId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_row();
        return $result[0] >= 3; 
    }

    /**
     * Checks for a 3-day consistency streak (100% progress ratio in daily_plan).
     */
    private function checkThreeDayStreak(): bool {
        // 1. Get all dates where progress was 100%
        $stmt = $this->conn->prepare("SELECT PLAN_DATE FROM daily_plan WHERE STUDENT_ID = ? AND PROGRESS_RATIO = 100 ORDER BY PLAN_DATE DESC");
        $stmt->bind_param("i", $this->studentId);
        $stmt->execute();
        $result = $stmt->get_result();
        $completedDays = [];
        while ($row = $result->fetch_assoc()) {
            $completedDays[] = $row['PLAN_DATE'];
        }

        if (count($completedDays) < 3) {
            return false;
        }

        // 2. Check for 3 consecutive days
        // Convert to DateTime objects for reliable date arithmetic and sort ascending
        $dt_days = array_map(function($d) { return new DateTime($d); }, $completedDays);
        sort($dt_days); // Sort oldest to newest

        // Loop through the completed days, looking for three in a row
        for ($i = 0; $i <= count($dt_days) - 3; $i++) {
            $day1 = $dt_days[$i];
            $day2 = $dt_days[$i+1];
            $day3 = $dt_days[$i+2];

            // Check if day2 is exactly one day after day1, and day3 is exactly one day after day2
            if (
                $day1->diff($day2)->days == 1 && $day1->diff($day2)->invert == 1 &&
                $day2->diff($day3)->days == 1 && $day2->diff($day3)->invert == 1
            ) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Checks if the student has completed any Pomodoro session (from pomodoro_session).
     */
    private function checkPomodoroStarter(): bool {
        $stmt = $this->conn->prepare("SELECT COUNT(*) FROM pomodoro_session WHERE STUDENT_ID = ?");
        $stmt->bind_param("i", $this->studentId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_row();
        return $result[0] > 0;
    }

    /**
     * Main method to get all achievements and their status.
     * @return array An array of achievements with a calculated 'unlocked' status.
     */
    public function getUserAchievements(): array {
        $allAchievements = $this->getAllAchievements();
        $userAchievements = [];

        foreach ($allAchievements as $key => $achievement) {
            // Guard clause for missing check method
            if (!method_exists($this, $achievement['check_method'])) {
                error_log("Missing achievement check method: " . $achievement['check_method']);
                continue;
            }

            $isUnlocked = call_user_func([$this, $achievement['check_method']]);
            
            $userAchievements[] = [
                'id' => $key,
                'name' => $achievement['name'],
                'desc' => $achievement['desc'],
                'icon' => $achievement['icon'],
                'unlocked' => $isUnlocked
            ];
        }

        return $userAchievements;
    }
}
?>