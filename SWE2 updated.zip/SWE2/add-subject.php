<?php
require_once 'config.php';

// Redirect to login if not authenticated
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header('Location: log.php');
    exit();
}

$user_name = $_SESSION['user_name'];
$user_id = $_SESSION['user_id'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject_name = $_POST['subject_name'];
    $exam_date = $_POST['exam_date'];
    $chapters_count = $_POST['chapters'];
    
    // Build chapters string based on difficulties
    $chapters = [];
    for ($i = 1; $i <= $chapters_count; $i++) {
        $difficulty = $_POST["diff$i"];
        $chapters[] = "Chapter $i ($difficulty)";
    }
    $chapters_str = implode('; ', $chapters);
    
    // Insert subject into database
    $stmt = $pdo->prepare("INSERT INTO Exam (SUBJECT_NAME, EXAM_DATE, CHAPTERS, DIFFICULTY_LEVEL, STUDENT_ID) VALUES (?, ?, ?, ?, ?)");
    $difficulty_level = "Mixed";
    
    try {
        $stmt->execute([$subject_name, $exam_date, $chapters_str, $difficulty_level, $user_id]);
        header('Location: homepage.php');
        exit();
    } catch (PDOException $e) {
        $error = "Error adding subject: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Add Subject • PrepWise</title>
  <link rel="stylesheet" href="style.css" />
  <style>
    .add-page { max-width: 800px; }
    .add-head { margin-bottom: 2em; }
    .add-card { background: var(--surface); padding: 2em; border-radius: var(--radius); box-shadow: var(--shadow); }
    .form-grid { display: grid; gap: 1.5em; }
    .form-row { margin-bottom: 1em; }
    .choice-set { border: 1px solid var(--border); padding: 1.5em; border-radius: var(--radius); }
    .choice-grid { display: grid; gap: 1em; }
    .choice-line { display: grid; grid-template-columns: 50px 1fr; gap: 1em; align-items: center; }
    .select { width: 100%; padding: 0.75em; border: 1px solid var(--border); border-radius: 8px; }
  </style>
</head>
<body>
  <!-- Header -->
  <header class="header">
    <div class="container">
      <div class="nav">
        <a class="brand" href="homepage.php">
          <img src="PrepWiseLogo.png" alt="PrepWise Logo" class="logo-img">
          <span>PrepWise</span>
        </a>
        <nav>
          <a href="homepage.php">Home</a>
          <a href="plan.php">Plan</a>
          <a href="Pomodoro.php">Pomodoro</a>
          <a href="Achievements.php">Achievements</a>
          <a href="Profile.php">Profile</a>
          <a href="logout.php">Logout</a>
        </nav>
      </div>
    </div>
  </header>

  <main class="container add-page">
    <div class="add-head">
      <h1>Add Subject</h1>
      <p class="helper">Enter the subject details. The system will use the first N difficulty fields according to "Number of Chapters".</p>
    </div>

    <section class="add-card">
      <?php if (isset($error)): ?>
        <div style="color: red; background: #fef2f2; padding: 10px; border-radius: 8px; margin-bottom: 1em;">
          <?php echo $error; ?>
        </div>
      <?php endif; ?>

      <form method="POST">
        <div class="form-grid">
          <!-- Subject name -->
          <div class="form-row">
            <label for="subjectName">Subject Name</label>
            <input id="subjectName" class="input" type="text" name="subject_name" placeholder="e.g., Database" required />
          </div>

          <!-- Exam date -->
          <div class="form-row">
            <label for="examDate">Exam Date</label>
            <input id="examDate" class="input" type="date" name="exam_date" required />
          </div>

          <!-- Number of chapters -->
          <div class="form-row">
            <label for="chapters">Number of Chapters (max 4)</label>
            <select id="chapters" class="select" name="chapters" required onchange="updateDifficultyFields()">
              <option value="1">1 chapter</option>
              <option value="2">2 chapters</option>
              <option value="3">3 chapters</option>
              <option value="4">4 chapters</option>
            </select>
            <span class="helper">We'll use only the first N difficulty fields below.</span>
          </div>

          <!-- Difficulties -->
          <fieldset class="choice-set">
            <legend>Chapter Difficulties</legend>
            <div class="choice-grid">
              <div class="choice-line">
                <span>1</span>
                <select class="select" name="diff1" required>
                  <option value="easy">Easy</option>
                  <option value="medium">Medium</option>
                  <option value="hard">Hard</option>
                </select>
              </div>

              <div class="choice-line">
                <span>2</span>
                <select class="select" name="diff2">
                  <option value="easy">Easy</option>
                  <option value="medium">Medium</option>
                  <option value="hard">Hard</option>
                </select>
              </div>

              <div class="choice-line">
                <span>3</span>
                <select class="select" name="diff3">
                  <option value="easy">Easy</option>
                  <option value="medium">Medium</option>
                  <option value="hard">Hard</option>
                </select>
              </div>

              <div class="choice-line">
                <span>4</span>
                <select class="select" name="diff4">
                  <option value="easy">Easy</option>
                  <option value="medium">Medium</option>
                  <option value="hard">Hard</option>
                </select>
              </div>
            </div>
            <p class="helper" style="margin-top:6px;">
              Example: if chapters = 2, the system will use <strong>diff1–diff2</strong> and ignore the rest.
            </p>
          </fieldset>
        </div>

        <div class="actions">
          <button type="submit" class="btn">Save Subject</button>
          <a href="homepage.php" class="btn ghost">Cancel</a>
        </div>
      </form>
    </section>
  </main>

  <!-- Footer -->
  <footer>
    <div class="footer-container">
      <div class="logo">
        <div class="copyright">© 2025 PrepWise</div>
        <img src="PrepWiseLogo.png" alt="PrepWise logo" />
        <p class="textfooter">Smart study planner for students.</p>
      </div>

      <div class="social-media">
        <h3>Follow us</h3>
        <p><i>in</i> LinkedIn</p>
        <p><i>t</i> Twitter/X</p>
        <p><i>ig</i> Instagram</p>
      </div>

      <div class="contact-us">
        <h3>Contact</h3>
        <p><i>@</i> <a href="mailto:support@prepwise.app">support@prepwise.app</a></p>
        <p><i>☎</i> +966-555-000-000</p>
      </div>
    </div>
  </footer>

  <script>
    function updateDifficultyFields() {
      const chapters = document.getElementById('chapters').value;
      const difficultyFields = document.querySelectorAll('.choice-line');
      
      difficultyFields.forEach((field, index) => {
        if (index < chapters) {
          field.style.display = 'grid';
          field.querySelector('select').required = true;
        } else {
          field.style.display = 'none';
          field.querySelector('select').required = false;
        }
      });
    }

    // Initialize on page load
    document.addEventListener('DOMContentLoaded', updateDifficultyFields);
  </script>
</body>
</html>