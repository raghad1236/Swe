<?php
require_once 'config.php';

// Redirect to login if not authenticated
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header('Location: log.php');
    exit();
}

$user_name = $_SESSION['user_name'];
$user_id = $_SESSION['user_id'];

// Get user's subjects for selection (with exam dates)
$subjects_stmt = $pdo->prepare("SELECT SUBJECT_NAME, EXAM_DATE, CHAPTERS FROM Exam WHERE STUDENT_ID = ?");
$subjects_stmt->execute([$user_id]);
$subjects = $subjects_stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selected_subjects = $_POST['subjects'] ?? [];
    
    if (!empty($selected_subjects)) {
        generateStudyPlan($user_id, $selected_subjects, $pdo);
        header('Location: homepage.php');
        exit();
    } else {
        $error = "Please select at least one subject to generate a plan.";
    }
}

// Function to generate study plan with exam date consideration
function generateStudyPlan($user_id, $selected_subjects, $pdo) {
    // Get selected subjects with their chapters and exam dates
    $placeholders = str_repeat('?,', count($selected_subjects) - 1) . '?';
    $stmt = $pdo->prepare("SELECT SUBJECT_NAME, EXAM_DATE, CHAPTERS FROM Exam WHERE STUDENT_ID = ? AND SUBJECT_NAME IN ($placeholders)");
    $params = array_merge([$user_id], $selected_subjects);
    $stmt->execute($params);
    $subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $all_tasks = [];
    $earliest_exam_date = null;
    
    foreach ($subjects as $subject) {
        $chapters = explode(';', $subject['CHAPTERS']);
        $remaining_chapters = [];
        
        foreach ($chapters as $chapter) {
            $chapter = trim($chapter);
            if (!empty($chapter)) {
                // Check if chapter is already completed
                $check_stmt = $pdo->prepare("SELECT completed FROM chapter_status WHERE student_id = ? AND subject_name = ? AND chapter_name = ?");
                $check_stmt->execute([$user_id, $subject['SUBJECT_NAME'], $chapter]);
                $chapter_status = $check_stmt->fetch(PDO::FETCH_ASSOC);
                
                // Only include if not completed
                if (!$chapter_status || !$chapter_status['completed']) {
                    $remaining_chapters[] = $chapter;
                }
            }
        }
        
        // Track earliest exam date
        $exam_date = new DateTime($subject['EXAM_DATE']);
        if ($earliest_exam_date === null || $exam_date < $earliest_exam_date) {
            $earliest_exam_date = $exam_date;
        }
        
        foreach ($remaining_chapters as $chapter) {
            // Extract difficulty from chapter name
            $difficulty = extractDifficultyFromChapter($chapter);
            
            $all_tasks[] = [
                'subject' => $subject['SUBJECT_NAME'],
                'chapter' => $chapter,
                'difficulty' => $difficulty,
                'exam_date' => $subject['EXAM_DATE']
            ];
        }
    }
    
    // Organize tasks based on difficulty rules and exam dates
    organizeTasksByDifficultyWithExamDates($all_tasks, $user_id, $earliest_exam_date, $pdo);
}

// Function to extract difficulty from chapter name
function extractDifficultyFromChapter($chapter) {
    // Extract difficulty from format: "Chapter 1 (easy)"
    if (preg_match('/\((\w+)\)/', $chapter, $matches)) {
        return strtolower($matches[1]);
    }
    
    // Fallback: check for difficulty keywords
    $chapter_lower = strtolower($chapter);
    
    if (strpos($chapter_lower, 'hard') !== false) {
        return 'hard';
    } elseif (strpos($chapter_lower, 'medium') !== false) {
        return 'medium';
    } else {
        return 'easy';
    }
}

// ✅ FIXED: Function to organize tasks with proper difficulty combinations
function organizeTasksByDifficultyWithExamDates($tasks, $user_id, $earliest_exam_date, $pdo) {
    $daily_plans = [];
    $current_date = new DateTime(); // Start from TODAY
    $today = $current_date->format('Y-m-d');
    
    // Clear only future plans (keep today for migration)
    $tomorrow = (new DateTime())->modify('+1 day')->format('Y-m-d');
    $clear_stmt = $pdo->prepare("DELETE FROM Daily_Plan WHERE STUDENT_ID = ? AND PLAN_DATE >= ?");
    $clear_stmt->execute([$user_id, $tomorrow]);
    
    // Separate tasks by difficulty
    $hard_tasks = array_filter($tasks, function($task) { return $task['difficulty'] === 'hard'; });
    $medium_tasks = array_filter($tasks, function($task) { return $task['difficulty'] === 'medium'; });
    $easy_tasks = array_filter($tasks, function($task) { return $task['difficulty'] === 'easy'; });
    
    // ✅ FIXED: Schedule HARD tasks first (each gets own day)
    foreach ($hard_tasks as $hard_task) {
        $date_str = $current_date->format('Y-m-d');
        
        // Check if we're past exam date
        $task_exam_date = new DateTime($hard_task['exam_date']);
        $last_study_date = clone $task_exam_date;
        $last_study_date->modify('-1 day');
        
        if ($current_date > $last_study_date) {
            break; // Stop if past exam date
        }
        
        $daily_plans[$date_str][] = $hard_task;
        $current_date->modify('+1 day');
    }
    
    // ✅ FIXED: Schedule MEDIUM tasks (can combine with EASY)
    foreach ($medium_tasks as $medium_task) {
        $task_exam_date = new DateTime($medium_task['exam_date']);
        $last_study_date = clone $task_exam_date;
        $last_study_date->modify('-1 day');
        
        if ($current_date > $last_study_date) {
            break;
        }
        
        $date_str = $current_date->format('Y-m-d');
        
        // Check if we can add this medium task to current day
        if (canAddTaskToDay($daily_plans[$date_str] ?? [], $medium_task)) {
            $daily_plans[$date_str][] = $medium_task;
            
            // ✅ Try to add ONE easy task with the medium task
            if (!empty($easy_tasks)) {
                $easy_task = array_shift($easy_tasks);
                if (canAddTaskToDay($daily_plans[$date_str] ?? [], $easy_task)) {
                    $daily_plans[$date_str][] = $easy_task;
                } else {
                    array_unshift($easy_tasks, $easy_task); // Put back if can't add
                }
            }
            
            $current_date->modify('+1 day');
        } else {
            // If can't add to current day, try next day
            $current_date->modify('+1 day');
            $date_str = $current_date->format('Y-m-d');
            
            if ($current_date <= $last_study_date && canAddTaskToDay($daily_plans[$date_str] ?? [], $medium_task)) {
                $daily_plans[$date_str][] = $medium_task;
                
                // Try to add easy task
                if (!empty($easy_tasks)) {
                    $easy_task = array_shift($easy_tasks);
                    if (canAddTaskToDay($daily_plans[$date_str] ?? [], $easy_task)) {
                        $daily_plans[$date_str][] = $easy_task;
                    } else {
                        array_unshift($easy_tasks, $easy_task);
                    }
                }
                
                $current_date->modify('+1 day');
            }
        }
    }
    
    // ✅ FIXED: Schedule remaining EASY tasks (group 2 per day)
    while (!empty($easy_tasks)) {
        $easy_task = array_shift($easy_tasks);
        $task_exam_date = new DateTime($easy_task['exam_date']);
        $last_study_date = clone $task_exam_date;
        $last_study_date->modify('-1 day');
        
        if ($current_date > $last_study_date) {
            break;
        }
        
        $date_str = $current_date->format('Y-m-d');
        
        // Check if we can add this easy task to current day
        if (canAddTaskToDay($daily_plans[$date_str] ?? [], $easy_task)) {
            $daily_plans[$date_str][] = $easy_task;
            
            // ✅ Try to add SECOND easy task to same day
            if (!empty($easy_tasks)) {
                $second_easy = $easy_tasks[0]; // Peek at next easy task
                if (canAddTaskToDay($daily_plans[$date_str] ?? [], $second_easy)) {
                    $second_easy = array_shift($easy_tasks);
                    $daily_plans[$date_str][] = $second_easy;
                }
            }
            
            $current_date->modify('+1 day');
        } else {
            // If can't add to current day, try next day
            $current_date->modify('+1 day');
            $date_str = $current_date->format('Y-m-d');
            
            if ($current_date <= $last_study_date && canAddTaskToDay($daily_plans[$date_str] ?? [], $easy_task)) {
                $daily_plans[$date_str][] = $easy_task;
                
                // Try to add second easy task
                if (!empty($easy_tasks)) {
                    $second_easy = $easy_tasks[0];
                    if (canAddTaskToDay($daily_plans[$date_str] ?? [], $second_easy)) {
                        $second_easy = array_shift($easy_tasks);
                        $daily_plans[$date_str][] = $second_easy;
                    }
                }
                
                $current_date->modify('+1 day');
            }
        }
    }
    
    // Save to database
    foreach ($daily_plans as $date => $day_tasks) {
        if (!empty($day_tasks)) {
            $tasks_json = json_encode($day_tasks);
            $progress = 0;
            
            $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM Daily_Plan WHERE STUDENT_ID = ? AND PLAN_DATE = ?");
            $check_stmt->execute([$user_id, $date]);
            $exists = $check_stmt->fetchColumn();
            
            if ($exists) {
                $stmt = $pdo->prepare("UPDATE Daily_Plan SET TASKS = ?, PROGRESS_RATIO = ? WHERE STUDENT_ID = ? AND PLAN_DATE = ?");
                $stmt->execute([$tasks_json, $progress, $user_id, $date]);
            } else {
                $stmt = $pdo->prepare("INSERT INTO Daily_Plan (PLAN_DATE, TASKS, PROGRESS_RATIO, STUDENT_ID) VALUES (?, ?, ?, ?)");
                $stmt->execute([$date, $tasks_json, $progress, $user_id]);
            }
        }
    }
    
    return $daily_plans;
}

// Make sure this function exists (add it if not present)
function canAddTaskToDay($day_tasks, $new_task) {
    $hard_count = 0;
    $medium_count = 0;
    $easy_count = 0;
    
    foreach ($day_tasks as $task) {
        switch ($task['difficulty']) {
            case 'hard': $hard_count++; break;
            case 'medium': $medium_count++; break;
            case 'easy': $easy_count++; break;
        }
    }
    
    // Check individual task limits
    switch ($new_task['difficulty']) {
        case 'hard':
            return $hard_count == 0; // Only one hard task per day
        
        case 'medium':
            return $medium_count == 0; // One medium task per day
        
        case 'easy':
            return $easy_count < 2; // Up to 2 easy tasks per day
    }
    
    return false;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Generate Plan • PrepWise</title>
  <link rel="stylesheet" href="style.css" />
  <style>
    .add-page { max-width: 800px; }
    .add-head { margin-bottom: 2em; }
    .add-card { background: var(--surface); padding: 2em; border-radius: var(--radius); box-shadow: var(--shadow); }
    .form-grid { display: grid; gap: 1.5em; }
    .form-row { margin-bottom: 1em; }
    .choice-set { border: 1px solid var(--border); padding: 1.5em; border-radius: var(--radius); }
    .subject-checkbox { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; padding: 10px; border: 1px solid var(--border); border-radius: 8px; }
    .subject-checkbox:hover { background: var(--brand-ghost); }
    .error-message {
      color: var(--no-ink);
      background: var(--no-bg);
      padding: 12px;
      border-radius: 8px;
      margin: 10px 0;
      border: 1px solid var(--no-brd);
    }
    .info-box {
      background: var(--brand-ghost);
      padding: 15px;
      border-radius: 8px;
      margin: 15px 0;
      border-left: 4px solid var(--brand);
    }
    .exam-date {
      color: var(--muted);
      font-size: 0.9em;
    }
    .completed-chapter {
      color: var(--ok-ink);
      background: var(--ok-bg);
      padding: 2px 6px;
      border-radius: 4px;
      font-size: 0.8em;
      margin-left: 5px;
    }
  </style>
</head>
<body>
  <header class="header">
    <div class="container">
      <div class="nav">
        <a class="brand" href="homepage.php">
          <img src="PrepWiseLogo.png" alt="PrepWise Logo" class="logo-img">
          <span>PrepWise</span>
        </a>
        <nav>
          <a href="homepage.php">Home</a>
          <a href="plan.php">Plan</a>
          <a href="Pomodoro.php">Pomodoro</a>
          <a href="Achievements.php">Achievements</a>
          <a href="Profile.php">Profile</a>
          <a href="logout.php">Logout</a>
        </nav>
      </div>
    </div>
  </header>

  <main class="container add-page">
    <div class="add-head">
      <h1>Generate Study Plan</h1>
      <p class="helper">Select the subjects you want to include in your study plan. The system will automatically schedule tasks based on chapter difficulties and exam dates.</p>
    </div>

    <section class="add-card">
      <?php if (isset($error)): ?>
        <div class="error-message"><?php echo $error; ?></div>
      <?php endif; ?>

      <div class="info-box">
        <h3 style="margin-top: 0;">📋 Smart Scheduling Rules:</h3>
        <ul style="margin-bottom: 0;">
          <li><strong>Hard tasks:</strong> One per day (gets own day)</li>
          <li><strong>Medium tasks:</strong> Can be combined with one easy task</li>
          <li><strong>Easy tasks:</strong> Grouped 2 per day when possible</li>
          <li><strong>Exam dates:</strong> All studying finishes the day BEFORE the earliest exam</li>
          <li><strong>Completed chapters:</strong> Automatically excluded from new plans</li>
          <li><strong>Last day:</strong> Will always be an easy/review day (no hard tasks)</li>
        </ul>
      </div>

      <form method="POST">
        <div class="form-grid">
          <fieldset class="choice-set">
            <legend>Select Subjects</legend>
            <p class="helper">Choose the subjects you want to include in your study plan. Completed chapters are automatically excluded.</p>
            
            <?php if (count($subjects) > 0): ?>
              <?php 
              $earliest_exam = null;
              foreach ($subjects as $subject): 
                $exam_date = new DateTime($subject['EXAM_DATE']);
                if ($earliest_exam === null || $exam_date < $earliest_exam) {
                  $earliest_exam = $exam_date;
                }
                
                // Count completed chapters for this subject
                $chapters = explode(';', $subject['CHAPTERS']);
                $total_chapters = count($chapters);
                $completed_count = 0;
                foreach ($chapters as $chapter) {
                  $chapter = trim($chapter);
                  $check_stmt = $pdo->prepare("SELECT completed FROM chapter_status WHERE student_id = ? AND subject_name = ? AND chapter_name = ?");
                  $check_stmt->execute([$user_id, $subject['SUBJECT_NAME'], $chapter]);
                  if ($check_stmt->fetch()) {
                    $completed_count++;
                  }
                }
              ?>
                <div class="subject-checkbox">
                  <input type="checkbox" name="subjects[]" value="<?php echo htmlspecialchars($subject['SUBJECT_NAME']); ?>" id="subject_<?php echo htmlspecialchars($subject['SUBJECT_NAME']); ?>">
                  <label for="subject_<?php echo htmlspecialchars($subject['SUBJECT_NAME']); ?>" style="margin: 0; cursor: pointer;">
                    <strong><?php echo htmlspecialchars($subject['SUBJECT_NAME']); ?></strong>
                    <?php if ($completed_count > 0): ?>
                      <span class="completed-chapter"><?php echo $completed_count; ?> completed</span>
                    <?php endif; ?>
                    <br>
                    <small style="color: var(--muted);">Chapters: <?php echo htmlspecialchars($subject['CHAPTERS']); ?></small>
                    <br>
                    <small class="exam-date">📅 Exam: <?php echo htmlspecialchars($subject['EXAM_DATE']); ?></small>
                  </label>
                </div>
              <?php endforeach; ?>
              <?php if ($earliest_exam): ?>
                <div style="background: #e0f2fe; padding: 10px; border-radius: 8px; margin-top: 10px;">
                  <strong>Earliest Exam:</strong> <?php echo $earliest_exam->format('Y-m-d'); ?><br>
                  <small>All studying will finish on <?php echo $earliest_exam->modify('-1 day')->format('Y-m-d'); ?> (day before exam)</small>
                </div>
              <?php endif; ?>
            <?php else: ?>
              <p>No subjects found. <a href="add-subject.php">Add subjects first</a>.</p>
            <?php endif; ?>
          </fieldset>
        </div>

        <div class="actions">
          <button type="submit" class="btn">Generate Smart Study Plan</button>
          <a href="homepage.php" class="btn ghost">Cancel</a>
        </div>
      </form>
    </section>
  </main>

  <footer>
    <div class="footer-container">
      <div class="logo">
        <div class="copyright">© 2025 PrepWise</div>
        <img src="PrepWiseLogo.png" alt="PrepWise logo" />
        <p class="textfooter">Smart study planner for students.</p>
      </div>
      <div class="social-media">
        <h3>Follow us</h3>
        <p><i>in</i> LinkedIn</p>
        <p><i>t</i> Twitter/X</p>
        <p><i>ig</i> Instagram</p>
      </div>
      <div class="contact-us">
        <h3>Contact</h3>
        <p><i>@</i> <a href="mailto:support@prepwise.app">support@prepwise.app</a></p>
        <p><i>☎</i> +966-555-000-000</p>
      </div>
    </div>
  </footer>

  <script>
    // Select all checkbox functionality
    document.addEventListener('DOMContentLoaded', function() {
      const checkboxes = document.querySelectorAll('input[type="checkbox"]');
      const selectAllBtn = document.createElement('button');
      selectAllBtn.type = 'button';
      selectAllBtn.className = 'btn ghost';
      selectAllBtn.textContent = 'Select All';
      selectAllBtn.style.marginBottom = '15px';
      
      selectAllBtn.addEventListener('click', function() {
        const allChecked = Array.from(checkboxes).every(checkbox => checkbox.checked);
        checkboxes.forEach(checkbox => {
          checkbox.checked = !allChecked;
        });
        this.textContent = allChecked ? 'Select All' : 'Deselect All';
      });
      
      const form = document.querySelector('form');
      form.insertBefore(selectAllBtn, form.firstChild);
    });
  </script>
</body>
</html>