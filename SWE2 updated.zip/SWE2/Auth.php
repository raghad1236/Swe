<?php
/**
 * Class to manage the authenticated user context using PHP sessions.
 */
class Auth {
    /**
     * Retrieves the ID of the currently logged-in student from the session.
     * Redirects to login page if no user is authenticated.
     * * @return int The student ID.
     */
    public static function getStudentId(): int {
        // Ensure the session is started before accessing $_SESSION
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (isset($_SESSION['user_id']) && $_SESSION['logged_in'] === true) {
            return (int)$_SESSION['user_id'];
        } else {
            // User is not logged in, redirect them to the login page
            // Note: Assuming your login script is named login.php
            header('Location: log.php');
            exit();
        }
    }

    /**
     * Retrieves the name of the currently logged-in student.
     * @return string The student name, or null if not logged in.
     */
    public static function getStudentName(): ?string {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        return $_SESSION['user_name'] ?? null;
    }
}
?>