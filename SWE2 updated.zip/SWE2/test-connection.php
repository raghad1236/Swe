<?php
// Test database connection
echo "Testing database connection...<br>";

$host = 'localhost';
$username = 'root';
$password = 'root';
$database = 'PrepWiseDB';

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    echo "Database connected successfully!<br>";
}

// Test if tables exist
$tables = ['User', 'Exam', 'Daily_Plan', 'Pomodoro_Session', 'Admin', 'Reported_Problem'];
foreach ($tables as $table) {
    $result = $conn->query("SHOW TABLES LIKE '$table'");
    if ($result->num_rows > 0) {
        echo "Table '$table' exists ✓<br>";
    } else {
        echo "Table '$table' does NOT exist ✗<br>";
    }
}

$conn->close();
?>