<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Check user credentials
    $stmt = $pdo->prepare("SELECT STUDENT_ID, STUDENT_NAME, STUDENT_EMAIL FROM User WHERE STUDENT_EMAIL = ? AND STUDENT_PASSWORD = ?");
    $stmt->execute([$email, $password]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Login successful
        $_SESSION['user_id'] = $user['STUDENT_ID'];
        $_SESSION['user_name'] = $user['STUDENT_NAME'];
        $_SESSION['user_email'] = $user['STUDENT_EMAIL'];
        $_SESSION['logged_in'] = true;

        header('Location: homepage.php');
        exit();
    } else {
        // Login failed
        $error = "Invalid email or password";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Login • PrepWise</title>
  <link rel="stylesheet" href="style.css" />
  <style>
    .auth-container {
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 70vh;
      padding: 2em 0;
    }

    .auth-page {
      background: var(--surface);
      padding: 40px 30px;
      border-radius: var(--radius);
      box-shadow: var(--shadow);
      width: 100%;
      max-width: 400px;
      text-align: center;
    }

    .auth-logo {
      font-size: 28px;
      font-weight: 700;
      color: var(--brand);
      margin-bottom: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
    }

    .auth-tagline {
      color: var(--muted);
      margin-bottom: 30px;
      font-size: 14px;
    }

    .auth-page h1 {
      margin-bottom: 30px;
      color: var(--text);
      font-weight: 600;
      font-size: 24px;
    }

    .input-group {
      margin-bottom: 20px;
      text-align: left;
    }

    .auth-input {
      width: 100%;
      padding: 15px;
      border: 2px solid var(--border);
      border-radius: 10px;
      font-size: 16px;
      transition: all 0.3s ease;
      background: #f8f9fa;
    }

    .auth-input:focus {
      outline: none;
      border-color: var(--brand);
      background: #fff;
      box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
    }

    .auth-btn {
      padding: 15px 30px;
      border: none;
      border-radius: 10px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      width: 100%;
      margin: 5px 0;
    }

    .btn-primary {
      background: linear-gradient(135deg, var(--brand) 0%, var(--brand-2) 100%);
      color: #fff;
    }

    .btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
    }

    .error-message {
      color: #dc2626;
      background: #fef2f2;
      padding: 10px;
      border-radius: 8px;
      margin: 10px 0;
      border: 1px solid #fecaca;
    }
  </style>
</head>
<body>
  <!-- Header -->
  <header class="header">
    <div class="container">
      <div class="nav">
        <a class="brand" href="#">
          <img src="PrepWiseLogo.png" alt="PrepWise Logo" class="logo-img">
          <span>PrepWise</span>
        </a>
      </div>
    </div>
  </header>

  <!-- Main Auth Content -->
  <main class="container">
    <div class="auth-container">
      <!-- Login Form -->
      <div class="auth-page">
        <div class="auth-logo">
          <img src="PrepWiseLogo.png" alt="PrepWise Logo" style="width: 40px; height: 40px;">
          <span>PrepWise</span>
        </div>
        <p class="auth-tagline">Smart study planner for students</p>
        <h1>Welcome Back</h1>
        
        <?php if (isset($error)): ?>
          <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST" action="">
          <div class="input-group">
            <input name="email" type="email" placeholder="Email address" class="auth-input" required value="user1@prepwise.app">
          </div>
          <div class="input-group">
            <input name="password" type="password" placeholder="Password" class="auth-input" required value="pw1">
          </div>
          <button type="submit" class="auth-btn btn-primary">Log In</button>
        </form>

       
      </div>
    </div>
  </main>

  <!-- Footer -->
  <footer>
    <div class="footer-container">
      <div class="logo">
        <div class="copyright">© 2025 PrepWise</div>
        <img src="PrepWiseLogo.png" alt="PrepWise logo" />
        <p class="textfooter">Smart study planner for students.</p>
      </div>

      <div class="social-media">
        <h3>Follow us</h3>
        <p><i>in</i> LinkedIn</p>
        <p><i>t</i> Twitter/X</p>
        <p><i>ig</i> Instagram</p>
      </div>

      <div class="contact-us">
        <h3>Contact</h3>
        <p><i>@</i> <a href="mailto:support@prepwise.app">support@prepwise.app</a></p>
        <p><i>☎</i> +966-555-000-000</p>
      </div>
    </div>
  </footer>
</body>
</html>