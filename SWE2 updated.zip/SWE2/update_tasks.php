<?php
require_once 'config.php';

// Add dependency on the achievement logic and Auth components
require_once 'AchievementLogic.php'; // Required for achievement checks
require_once 'Auth.php'; // Required for Auth::getStudentName(), though only user_id is used here

// Redirect to login if not authenticated
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header('Location: log.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$today = date('Y-m-d');

// =======================================================
// NEW LOGIC: Setup for Achievement Check (Duplicated from achievements.php)
// =======================================================
// Configuration for the database connection
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root'); // CHANGE THIS to your database username
define('DB_PASSWORD', 'root'); // CHANGE THIS to your database password
define('DB_NAME', 'PrepWiseDB'); 

function connect_db_mysqli() {
    $conn = @new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
    if ($conn->connect_error) {
        error_log("Connection failed in update_tasks: " . $conn->connect_error);
        return null; // Return null on failure
    }
    $conn->set_charset("utf8mb4");
    return $conn;
}

// 1. Store initial achievement status
$initial_achievements = [];
$conn_mysqli = connect_db_mysqli();
if ($conn_mysqli) {
    $logic_initial = new AchievementLogic($user_id, $conn_mysqli);
    $initial_achievements = $logic_initial->getUserAchievements();
    $conn_mysqli->close();
} else {
    error_log("Skipping initial achievement check in update_tasks due to DB error.");
}
// =======================================================
// END NEW LOGIC SETUP
// =======================================================


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get today's tasks from database
    $tasks_stmt = $pdo->prepare("SELECT TASKS FROM Daily_Plan WHERE STUDENT_ID = ? AND PLAN_DATE = ?");
    $tasks_stmt->execute([$user_id, $today]);
    $today_tasks_data = $tasks_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($today_tasks_data) {
        $today_tasks = json_decode($today_tasks_data['TASKS'], true) ?: [];
        $completed_chapters = [];
        $completed_tasks = $_POST['done'] ?? []; // SIMPLE ARRAY FORMAT
        
        // Update completion status based on form data
        foreach ($today_tasks as $index => &$task) {
            $was_completed = isset($task['completed']) && $task['completed'];
            $is_completed = isset($completed_tasks[$index]); // Simple array format
            $task['completed'] = $is_completed;
            
            // Track newly completed chapters
            if ($is_completed && !$was_completed) {
                $completed_chapters[] = [
                    'subject' => $task['subject'],
                    'chapter' => $task['chapter']
                ];
            }
        }
        
        // Update chapter status in database for newly completed chapters
        foreach ($completed_chapters as $chapter) {
            // Check if chapter status already exists
            $check_stmt = $pdo->prepare("SELECT id FROM chapter_status WHERE student_id = ? AND subject_name = ? AND chapter_name = ?");
            $check_stmt->execute([$user_id, $chapter['subject'], $chapter['chapter']]);
            
            if ($check_stmt->fetch()) {
                // Update existing
                $update_stmt = $pdo->prepare("UPDATE chapter_status SET completed = TRUE, completed_date = ? WHERE student_id = ? AND subject_name = ? AND chapter_name = ?");
                $update_stmt->execute([$today, $user_id, $chapter['subject'], $chapter['chapter']]);
            } else {
                // Insert new
                $insert_stmt = $pdo->prepare("INSERT INTO chapter_status (student_id, subject_name, chapter_name, completed, completed_date) VALUES (?, ?, ?, TRUE, ?)");
                $insert_stmt->execute([$user_id, $chapter['subject'], $chapter['chapter'], $today]);
            }
        }

        // =======================================================
        // NEW LOGIC: Check for newly unlocked badges after DB update
        // =======================================================
        if (!empty($initial_achievements)) {
            $conn_mysqli = connect_db_mysqli();
            if ($conn_mysqli) {
                $logic_final = new AchievementLogic($user_id, $conn_mysqli);
                $final_achievements = $logic_final->getUserAchievements();
                $conn_mysqli->close();
                
                // Compare initial vs final to find newly unlocked
                $newly_unlocked = [];
                foreach ($final_achievements as $final_badge) {
                    $initial_state = null;
                    // Find the initial state of this badge
                    foreach ($initial_achievements as $initial_a) {
                        if ($initial_a['id'] === $final_badge['id']) {
                            $initial_state = $initial_a;
                            break;
                        }
                    }
                    
                    // If it was locked initially AND is now unlocked
                    if ($initial_state && !$initial_state['unlocked'] && $final_badge['unlocked']) {
                        $newly_unlocked[] = $final_badge['name'];
                    }
                }

                // Set session for pop-up if a new badge was unlocked
                if (!empty($newly_unlocked)) {
                    // We only store the first one for the pop-up, to keep it simple.
                    $_SESSION['new_badge_pop'] = ['name' => $newly_unlocked[0]];
                }
            }
        }
        // =======================================================
        // END NEW LOGIC
        // =======================================================
        
        // Calculate progress
        $total_tasks = count($today_tasks);
        $completed_count = count(array_filter($today_tasks, function($task) {
            return isset($task['completed']) && $task['completed'];
        }));
        $progress_ratio = $total_tasks > 0 ? round(($completed_count / $total_tasks) * 100) : 0;
        
        // Update database
        $tasks_json = json_encode($today_tasks);
        $update_stmt = $pdo->prepare("UPDATE Daily_Plan SET TASKS = ?, PROGRESS_RATIO = ? WHERE STUDENT_ID = ? AND PLAN_DATE = ?");
        $update_stmt->execute([$tasks_json, $progress_ratio, $user_id, $today]);
        
        // ✅ OPTIONAL: Remove this line to avoid migration conflicts
        // Move incomplete tasks to tomorrow
        // moveIncompleteTasksToTomorrow($user_id, $today, $today_tasks, $pdo);
    }
}

// Function to move incomplete tasks to the next day
function moveIncompleteTasksToTomorrow($user_id, $today, $today_tasks, $pdo) {
    $incomplete_tasks = array_filter($today_tasks, function($task) {
        return !(isset($task['completed']) && $task['completed']);
    });
    
    if (!empty($incomplete_tasks)) {
        $tomorrow = date('Y-m-d', strtotime('+1 day'));
        
        // Check if tomorrow already has tasks
        $tomorrow_stmt = $pdo->prepare("SELECT TASKS FROM Daily_Plan WHERE STUDENT_ID = ? AND PLAN_DATE = ?");
        $tomorrow_stmt->execute([$user_id, $tomorrow]);
        $tomorrow_data = $tomorrow_stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($tomorrow_data) {
            // Merge with existing tasks
            $tomorrow_tasks = json_decode($tomorrow_data['TASKS'], true) ?: [];
            $merged_tasks = array_merge($tomorrow_tasks, array_values($incomplete_tasks));
            
            $tasks_json = json_encode($merged_tasks);
            $update_stmt = $pdo->prepare("UPDATE Daily_Plan SET TASKS = ? WHERE STUDENT_ID = ? AND PLAN_DATE = ?");
            $update_stmt->execute([$tasks_json, $user_id, $tomorrow]);
        } else {
            // Create new entry for tomorrow
            $tasks_json = json_encode(array_values($incomplete_tasks));
            $insert_stmt = $pdo->prepare("INSERT INTO Daily_Plan (PLAN_DATE, TASKS, PROGRESS_RATIO, STUDENT_ID) VALUES (?, ?, 0, ?)");
            $insert_stmt->execute([$tomorrow, $tasks_json, $user_id]);
        }
    }
}

// Redirect back to homepage
header('Location: homepage.php');
exit();
?>