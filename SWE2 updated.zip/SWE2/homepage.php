<?php
require_once 'config.php';

// Redirect to login if not authenticated
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header('Location: log.php');
    exit();
}

$user_name = $_SESSION['user_name'];
$user_id = $_SESSION['user_id'];

function migrateIncompleteTasks($user_id, $pdo) {
    $today = date('Y-m-d');
    
    // ✅ FIXED: Include today in the search to catch tasks from current day
    $stmt = $pdo->prepare("SELECT PLAN_DATE, TASKS FROM Daily_Plan WHERE STUDENT_ID = ? AND PLAN_DATE <= ? ORDER BY PLAN_DATE ASC");
    $stmt->execute([$user_id, $today]);
    $past_plans = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $all_incomplete_tasks = [];
    $dates_to_clear = [];
    
    foreach ($past_plans as $plan) {
        // ✅ FIXED: Don't process today's tasks for migration (only move older ones)
        if ($plan['PLAN_DATE'] === $today) {
            continue;
        }
        
        $tasks = json_decode($plan['TASKS'], true) ?: [];
        $incomplete_tasks = array_filter($tasks, function($task) {
            return !isset($task['completed']) || !$task['completed'];
        });
        
        if (!empty($incomplete_tasks)) {
            // ✅ FIXED: Add exam date check before migrating
            $filtered_tasks = [];
            foreach ($incomplete_tasks as $task) {
                // Check if task has exam date and if it's already passed
                if (isset($task['exam_date']) && $task['exam_date'] <= $today) {
                    // Skip tasks whose exam date has passed
                    continue;
                }
                $filtered_tasks[] = $task;
            }
            
            if (!empty($filtered_tasks)) {
                $all_incomplete_tasks = array_merge($all_incomplete_tasks, $filtered_tasks);
                $dates_to_clear[] = $plan['PLAN_DATE'];
            }
        }
    }
    
    // If we found stuck tasks, move them to TODAY
    if (!empty($all_incomplete_tasks)) {
        // Get today's current tasks
        $today_stmt = $pdo->prepare("SELECT TASKS FROM Daily_Plan WHERE STUDENT_ID = ? AND PLAN_DATE = ?");
        $today_stmt->execute([$user_id, $today]);
        $today_data = $today_stmt->fetch(PDO::FETCH_ASSOC);
        
        $today_tasks = [];
        if ($today_data) {
            $today_tasks = json_decode($today_data['TASKS'], true) ?: [];
        }
        
        // Combine stuck tasks + today's tasks
        $combined_tasks = array_merge($all_incomplete_tasks, $today_tasks);
        
        // Save to TODAY
        $tasks_json = json_encode($combined_tasks);
        $progress = calculateProgress($combined_tasks);
        
        if ($today_data) {
            $update_stmt = $pdo->prepare("UPDATE Daily_Plan SET TASKS = ?, PROGRESS_RATIO = ? WHERE STUDENT_ID = ? AND PLAN_DATE = ?");
            $update_stmt->execute([$tasks_json, $progress, $user_id, $today]);
        } else {
            $insert_stmt = $pdo->prepare("INSERT INTO Daily_Plan (PLAN_DATE, TASKS, PROGRESS_RATIO, STUDENT_ID) VALUES (?, ?, ?, ?)");
            $insert_stmt->execute([$today, $tasks_json, $progress, $user_id]);
        }
        
        // Clear all the old dates where tasks were stuck
        foreach ($dates_to_clear as $old_date) {
            $delete_stmt = $pdo->prepare("DELETE FROM Daily_Plan WHERE STUDENT_ID = ? AND PLAN_DATE = ?");
            $delete_stmt->execute([$user_id, $old_date]);
        }
        
        return count($all_incomplete_tasks); // Return count of migrated tasks
    }
    
    return 0;
}

function calculateTaskPriority($task, $earliest_exam) {
    $priority = 0;
    
    // Difficulty weights
    $difficulty_weights = [
        'hard' => 3,
        'medium' => 2, 
        'easy' => 1
    ];
    
    // Add difficulty priority
    $priority += $difficulty_weights[$task['difficulty']] ?? 1;
    
    // Add urgency priority (closer to exam = higher priority)
    if ($earliest_exam && isset($task['exam_date'])) {
        $days_until_exam = date_diff(
            new DateTime($task['exam_date']),
            new DateTime(date('Y-m-d'))
        )->days;
        
        if ($days_until_exam <= 3) {
            $priority += 5; // Critical urgency
        } elseif ($days_until_exam <= 7) {
            $priority += 3; // High urgency
        }
    }
    
    return $priority;
}

function redistributeTasks($user_id, $incomplete_tasks, $start_date, $exam_date, $pdo) {
    $current_date = new DateTime($start_date);
    $exam_datetime = $exam_date ? new DateTime($exam_date) : null;
    
    // Get existing planned days from today until exam
    $planned_days = [];
    if ($exam_datetime) {
        $stmt = $pdo->prepare("SELECT PLAN_DATE, TASKS FROM Daily_Plan 
                              WHERE STUDENT_ID = ? AND PLAN_DATE >= ? AND PLAN_DATE < ? 
                              ORDER BY PLAN_DATE ASC");
        $stmt->execute([$user_id, $start_date, $exam_date]);
    } else {
        $stmt = $pdo->prepare("SELECT PLAN_DATE, TASKS FROM Daily_Plan 
                              WHERE STUDENT_ID = ? AND PLAN_DATE >= ? 
                              ORDER BY PLAN_DATE ASC");
        $stmt->execute([$user_id, $start_date]);
    }
    
    $existing_plans = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($existing_plans as $plan) {
        $planned_days[$plan['PLAN_DATE']] = json_decode($plan['TASKS'], true) ?: [];
    }
    
    // Redistribute incomplete tasks following the same rules as generate-plan.php
    foreach ($incomplete_tasks as $task) {
        $placed = false;
        $check_date = clone $current_date;
        
        while (!$placed && (!$exam_datetime || $check_date < $exam_datetime)) {
            $date_str = $check_date->format('Y-m-d');
            $day_tasks = $planned_days[$date_str] ?? [];
            
            if (canAddTaskToDay($day_tasks, $task)) {
                $day_tasks[] = $task;
                $planned_days[$date_str] = $day_tasks;
                $placed = true;
            } else {
                $check_date->modify('+1 day');
            }
        }
        
        // If we couldn't place it before exam, place it on the last available day
        if (!$placed && $exam_datetime) {
            $last_study_day = clone $exam_datetime;
            $last_study_day->modify('-1 day');
            $date_str = $last_study_day->format('Y-m-d');
            
            $planned_days[$date_str] = array_merge($planned_days[$date_str] ?? [], [$task]);
        }
    }
    
    // Update the database with redistributed plans
    foreach ($planned_days as $date => $tasks) {
        if (!empty($tasks)) {
            $tasks_json = json_encode($tasks);
            $progress = calculateProgress($tasks);
            
            if (isset($existing_plans[$date])) {
                $stmt = $pdo->prepare("UPDATE Daily_Plan SET TASKS = ?, PROGRESS_RATIO = ? 
                                      WHERE STUDENT_ID = ? AND PLAN_DATE = ?");
                $stmt->execute([$tasks_json, $progress, $user_id, $date]);
            } else {
                $stmt = $pdo->prepare("INSERT INTO Daily_Plan (PLAN_DATE, TASKS, PROGRESS_RATIO, STUDENT_ID) 
                                      VALUES (?, ?, ?, ?)");
                $stmt->execute([$date, $tasks_json, $progress, $user_id]);
            }
        }
    }
}

function canAddTaskToDay($day_tasks, $new_task) {
    $hard_count = 0;
    $medium_count = 0;
    $easy_count = 0;
    
    foreach ($day_tasks as $task) {
        switch ($task['difficulty']) {
            case 'hard': $hard_count++; break;
            case 'medium': $medium_count++; break;
            case 'easy': $easy_count++; break;
        }
    }
    
    // Apply the same rules as generate-plan.php
    switch ($new_task['difficulty']) {
        case 'hard':
            return $hard_count == 0; // Only one hard task per day
        
        case 'medium':
            return $medium_count == 0; // One medium task per day
        
        case 'easy':
            return $easy_count < 2; // Up to 2 easy tasks per day
    }
    
    return false;
}

function calculateProgress($tasks) {
    $completed = count(array_filter($tasks, function($task) {
        return isset($task['completed']) && $task['completed'];
    }));
    
    return $completed > 0 ? round(($completed / count($tasks)) * 100) : 0;
}

// Run migration and get result
$migrated_count = migrateIncompleteTasks($user_id, $pdo);

// TEMPORARY DEBUG - Add this to see what's happening
echo "<div style='background: #ff4444; color: white; padding: 15px; margin: 10px; border-radius: 8px;'>";
echo "<h3>🚨 DEBUG MIGRATION</h3>";
echo "Today: " . date('Y-m-d') . "<br>";
echo "Server Time: " . date('Y-m-d H:i:s') . "<br>";
echo "Tasks migrated: " . $migrated_count . "<br>";

// Check what dates exist in database
$debug_stmt = $pdo->prepare("SELECT PLAN_DATE, COUNT(*) as task_count FROM Daily_Plan WHERE STUDENT_ID = ? GROUP BY PLAN_DATE ORDER BY PLAN_DATE");
$debug_stmt->execute([$user_id]);
$debug_dates = $debug_stmt->fetchAll(PDO::FETCH_ASSOC);

echo "Dates in database:<br>";
foreach ($debug_dates as $date_info) {
    echo "- " . $date_info['PLAN_DATE'] . " (" . $date_info['task_count'] . " tasks)<br>";
}

// ✅ FIXED: Check for correct year (2025 instead of 2023)
$nov30_stmt = $pdo->prepare("SELECT COUNT(*) as count FROM Daily_Plan WHERE STUDENT_ID = ? AND PLAN_DATE = '2025-11-30'");
$nov30_stmt->execute([$user_id]);
$nov30_count = $nov30_stmt->fetch(PDO::FETCH_ASSOC)['count'];

echo "November 30th tasks: " . $nov30_count . "<br>";
echo "</div>";

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Add subject
    if (isset($_POST['add_subject'])) {
        $subject_name = $_POST['subject_name'];
        $exam_date = $_POST['exam_date'];
        $chapters = $_POST['chapters'];
        
        // Insert subject into database
        $stmt = $pdo->prepare("INSERT INTO Exam (SUBJECT_NAME, EXAM_DATE, CHAPTERS, DIFFICULTY_LEVEL, STUDENT_ID) VALUES (?, ?, ?, ?, ?)");
        $difficulty_level = "Mixed";
        $stmt->execute([$subject_name, $exam_date, $chapters, $difficulty_level, $user_id]);
        
        header('Location: homepage.php');
        exit();
    }
}

// Get user's subjects
$subjects_stmt = $pdo->prepare("SELECT SUBJECT_NAME, EXAM_DATE, CHAPTERS FROM Exam WHERE STUDENT_ID = ?");
$subjects_stmt->execute([$user_id]);
$subjects = $subjects_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get today's tasks
$today = date('Y-m-d');
$tasks_stmt = $pdo->prepare("SELECT TASKS, PROGRESS_RATIO FROM Daily_Plan WHERE STUDENT_ID = ? AND PLAN_DATE = ?");
$tasks_stmt->execute([$user_id, $today]);
$today_data = $tasks_stmt->fetch(PDO::FETCH_ASSOC);
$today_tasks = [];
$completed_tasks = 0;
$progress_ratio = 0;

if ($today_data) {
    $today_tasks = json_decode($today_data['TASKS'], true) ?: [];
    $progress_ratio = $today_data['PROGRESS_RATIO'];
    $completed_tasks = count(array_filter($today_tasks, function($task) {
        return isset($task['completed']) && $task['completed'];
    }));
}

// Get ALL upcoming tasks (not just today's)
$all_tasks_stmt = $pdo->prepare("SELECT PLAN_DATE, TASKS, PROGRESS_RATIO FROM Daily_Plan WHERE STUDENT_ID = ? AND PLAN_DATE >= ? ORDER BY PLAN_DATE ASC");
$all_tasks_stmt->execute([$user_id, $today]);
$all_daily_plans = $all_tasks_stmt->fetchAll(PDO::FETCH_ASSOC);

// Organize all tasks by date
$all_tasks_by_date = [];
$total_upcoming_tasks = 0;
$total_completed_tasks = 0;

foreach ($all_daily_plans as $plan) {
    $tasks = json_decode($plan['TASKS'], true) ?: [];
    $all_tasks_by_date[$plan['PLAN_DATE']] = [
        'tasks' => $tasks,
        'progress_ratio' => $plan['PROGRESS_RATIO']
    ];
    
    $total_upcoming_tasks += count($tasks);
    $total_completed_tasks += count(array_filter($tasks, function($task) {
        return isset($task['completed']) && $task['completed'];
    }));
}

// Calculate exam progress from chapter_status table
$exam_progress = [];
foreach ($subjects as $subject) {
    $subject_name = $subject['SUBJECT_NAME'];
    $chapters = explode(';', $subject['CHAPTERS']);
    $total_chapters = count($chapters);
    $completed_chapters = 0;
    
    // Count completed chapters for this subject
    foreach ($chapters as $chapter) {
        $chapter = trim($chapter);
        $check_stmt = $pdo->prepare("SELECT completed FROM chapter_status WHERE student_id = ? AND subject_name = ? AND chapter_name = ?");
        $check_stmt->execute([$user_id, $subject_name, $chapter]);
        $chapter_status = $check_stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($chapter_status && $chapter_status['completed']) {
            $completed_chapters++;
        }
    }
    
    $progress = $total_chapters > 0 ? round(($completed_chapters / $total_chapters) * 100) : 0;
    $exam_progress[$subject_name] = [
        'completed' => $completed_chapters,
        'total' => $total_chapters,
        'progress' => $progress
    ];
}

// Get upcoming exams
$upcoming_exams = $subjects;

// =======================================================
// NEW LOGIC: Check for badge popup session data
// =======================================================
$showPopup = false; 
$unlockedBadgeName = "New Badge"; 

if (isset($_SESSION['new_badge_pop'])) {
    $showPopup = true;
    $unlockedBadgeName = $_SESSION['new_badge_pop']['name'] ?? "New Badge";
    // Clear the session variable immediately after reading it
    unset($_SESSION['new_badge_pop']); 
}
// =======================================================
// END NEW LOGIC
// =======================================================

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Homepage • PrepWise</title>
  <link rel="stylesheet" href="style.css" />
  <style>
    .difficulty-easy { color: var(--ok-ink); background: var(--ok-bg); padding: 4px 8px; border-radius: 6px; font-size: 12px; }
    .difficulty-medium { color: var(--warn-ink); background: var(--warn-bg); padding: 4px 8px; border-radius: 6px; font-size: 12px; }
    .difficulty-hard { color: var(--no-ink); background: var(--no-bg); padding: 4px 8px; border-radius: 6px; font-size: 12px; }
    .task-completed { text-decoration: line-through; opacity: 0.7; }
    .date-header { 
        background: linear-gradient(45deg, var(--brand), var(--brand-2));
        color: white;
        padding: 12px 16px;
        margin: 20px 0 10px 0;
        border-radius: 8px;
        font-weight: 600;
    }
    .day-progress {
        font-size: 0.9em;
        color: var(--muted);
        margin-bottom: 10px;
    }
    .no-tasks { 
        text-align: center; 
        padding: 20px; 
        color: var(--muted);
        font-style: italic;
    }
    .exam-progress-detail {
        font-size: 0.8em;
        color: var(--muted);
        margin-top: 4px;
    }
    .chapter-number {
        font-weight: 600;
        color: var(--text);
    }
  </style>
</head>
<body>
  <header class="header">
    <div class="container">
      <div class="nav">
        <a class="brand" href="homepage.php">
          <img src="PrepWiseLogo.png" alt="PrepWise Logo" class="logo-img">
          <span>PrepWise</span>
        </a>
        <nav>
          <a href="#" aria-current="page" style="font-weight:700;">Home</a>
          <a href="plan.php">Plan</a>
          <a href="Pomodoro.php">Pomodoro</a>
          <a href="Achievements.php">Achievements</a>
          <a href="Profile.php">Profile</a>
          <a href="logout.php">Logout</a>
        </nav>
      </div>
    </div>
  </header>

  <main class="container">
    <?php if ($showPopup): ?>
    <div style="background:#EEF2FF; border:1px solid #C7D2FE; padding:15px; border-radius:8px; margin-bottom: 20px; font-size: 1.1em; color: var(--text);">
        🎉 Congratulations<?php echo htmlspecialchars($user_name) ? ", " . htmlspecialchars($user_name) : ""; ?>! You unlocked a new badge: <strong>“<?php echo htmlspecialchars($unlockedBadgeName); ?>”</strong>!
        <a href="Achievements.php" style="margin-left: 10px; color: var(--brand); text-decoration: underline;">View Achievements</a>
    </div>
    <?php endif; ?>
    <section class="hero">
      <div>
        <h1>Welcome, <?php echo htmlspecialchars($user_name); ?>! 👋</h1>
        <p>Your focus for today is ready. Keep the streak going.</p>

        <div class="actions">
          <a class="btn" href="Pomodoro.php">Start Pomodoro</a>
          <a class="btn ghost" href="plan.php">Open Plan Page</a>
          <a class="btn secondary" href="plan.php">Export Full Schedule</a>
        </div>
      </div>

      <div class="card-1" aria-label="Today's progress">
        <h3 style="margin-top:0;">Today's Progress</h3>
        <p class="helper"><?php echo $completed_tasks; ?> of <?php echo count($today_tasks); ?> tasks completed</p>
        <progress value="<?php echo $completed_tasks; ?>" max="<?php echo count($today_tasks); ?>" style="width:100%; height:1.25em;"></progress>
        <p class="helper" style="margin-top:0.5em;">
          <?php echo $progress_ratio; ?>% complete
        </p>
        
        <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid var(--border);">
          <h4 style="margin: 0 0 8px 0;">Overall Progress</h4>
          <p class="helper" style="margin: 0;"><?php echo $total_completed_tasks; ?> of <?php echo $total_upcoming_tasks; ?> total tasks completed</p>
          <progress value="<?php echo $total_completed_tasks; ?>" max="<?php echo $total_upcoming_tasks; ?>" style="width:100%; height:1.25em;"></progress>
        </div>
      </div>
    </section>

    <section class="grid-2" style="margin-top:1.5em;">
      <div class="card-1">
        <div class="row between center">
          <h2 style="margin:0;">Subjects Table</h2>
          <div class="filters">
            <label for="filterSubj" class="helper" style="align-self:center;">Filter</label>
            <select id="filterSubj">
              <option>All Subjects</option>
              <?php foreach ($subjects as $subject): ?>
                <option><?php echo htmlspecialchars($subject['SUBJECT_NAME']); ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>

        <p class="helper" style="margin-top:0.5em;">
          Any change here (add/edit/delete/generate) updates all other pages automatically.
        </p>

        <table class="table" aria-describedby="subjects-note">
          <thead>
            <tr>
              <th class="col-subject">Subject</th>
              <th class="col-date">Exam Date</th>
              <th class="col-actions">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php if (count($subjects) > 0): ?>
              <?php foreach ($subjects as $subject): ?>
                <tr>
                  <td class="td-clip" title="<?php echo htmlspecialchars($subject['SUBJECT_NAME']); ?>">
                    <?php echo htmlspecialchars($subject['SUBJECT_NAME']); ?>
                  </td>
                  <td class="col-date">
                    <time datetime="<?php echo htmlspecialchars($subject['EXAM_DATE']); ?>">
                      <?php echo htmlspecialchars($subject['EXAM_DATE']); ?>
                    </time>
                  </td>
                  <td>
                    <div class="cell-actions">
                      <a class="btn ghost" href="edit-subject.php?subject=<?php echo urlencode($subject['SUBJECT_NAME']); ?>">Edit</a>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr>
                <td colspan="3" style="text-align: center;">No subjects added yet</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>

        <div class="table-actions-right">
          <a class="btn" href="generate-plan.php">Generate Plan</a>
          <a class="btn" href="add-subject.php">Add Subject</a>
        </div>
      </div>

      <div class="card-1">
        <h2 style="margin-top:0;">Today's Tasks</h2>
        <p class="helper">Check <strong>Done</strong> and click Save. Unchecked tasks will be automatically moved to tomorrow.</p>

        <form method="POST" action="update_tasks.php">
          <table class="table tasks-table">
            <thead>
              <tr>
                <th class="col-task">Task</th>
                <th class="col-subject">Subject</th>
                <th class="col-date">Difficulty</th>
                <th class="col-status">Done</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($today_tasks)): ?>
                <?php foreach ($today_tasks as $index => $task): ?>
                  <tr class="<?php echo isset($task['completed']) && $task['completed'] ? 'task-completed' : ''; ?>">
                    <td><?php echo htmlspecialchars($task['chapter']); ?></td>
                    <td><?php echo htmlspecialchars($task['subject']); ?></td>
                    <td>
                      <span class="difficulty-<?php echo $task['difficulty']; ?>">
                        <?php echo ucfirst($task['difficulty']); ?>
                      </span>
                    </td>
                    <td class="col-status">
                      <input class="chk" type="checkbox" name="done[<?php echo $index; ?>]" value="1" 
                             <?php echo (isset($task['completed']) && $task['completed']) ? 'checked' : ''; ?>
                             aria-label="Mark task <?php echo $index; ?> done">
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr>
                  <td colspan="4" style="text-align: center;">No tasks for today. <a href="generate-plan.php">Generate a study plan first!</a></td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>

          <?php if (!empty($today_tasks)): ?>
          <div class="table-actions-right">
            <button type="submit" class="btn">Save Task Status</button>
          </div>
          <?php endif; ?>
        </form>
      </div>
    </section>

        <section class="card-1" style="margin-top:1.25em;">
      <h2 style="margin-top:0;">Full Study Timeline</h2>
      <p class="helper">Your complete study schedule from today until exams. Incomplete tasks are automatically moved to the next day.</p>

      <?php if (!empty($all_tasks_by_date)): ?>
        <?php foreach ($all_tasks_by_date as $date => $day_data): 
          $is_today = $date === $today;
          $day_tasks = $day_data['tasks'];
          $day_completed = count(array_filter($day_tasks, function($task) {
            return isset($task['completed']) && $task['completed'];
          }));
          $day_total = count($day_tasks);
          $day_progress = $day_total > 0 ? round(($day_completed / $day_total) * 100) : 0;
        ?>
          <div class="date-header">
            <?php echo date('l, F j, Y', strtotime($date)); ?>
            <?php if ($is_today): ?><span style="background: white; color: var(--brand); padding: 2px 8px; border-radius: 12px; margin-left: 10px; font-size: 0.8em;">TODAY</span><?php endif; ?>
          </div>
          
          <div class="day-progress">
            Progress: <?php echo $day_completed; ?> of <?php echo $day_total; ?> tasks completed (<?php echo $day_progress; ?>%)
            <progress value="<?php echo $day_completed; ?>" max="<?php echo $day_total; ?>" style="width: 200px; height: 8px; margin-left: 10px;"></progress>
          </div>

          <?php if (!empty($day_tasks)): ?>
            <table class="table tasks-table">
              <thead>
                <tr>
                  <th class="col-task">Task</th>
                  <th class="col-subject">Subject</th>
                  <th class="col-date">Difficulty</th>
                  <th class="col-status">Status</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($day_tasks as $index => $task): 
                  // Extract chapter number from chapter name (e.g., "Chapter 1 (easy)" -> "Chapter 1")
                  $chapter_display = preg_replace('/\s*\(.*\)/', '', $task['chapter']);
                ?>
                  <tr class="<?php echo isset($task['completed']) && $task['completed'] ? 'task-completed' : ''; ?>">
                    <td>
                      <span class="chapter-number"><?php echo htmlspecialchars($chapter_display); ?></span>
                    </td>
                    <td><?php echo htmlspecialchars($task['subject']); ?></td>
                    <td>
                      <span class="difficulty-<?php echo $task['difficulty']; ?>">
                        <?php echo ucfirst($task['difficulty']); ?>
                      </span>
                    </td>
                    <td class="col-status">
                      <?php if ($is_today): ?>
                        <span class="badge <?php echo (isset($task['completed']) && $task['completed']) ? 'ok' : 'pending'; ?>">
                          <?php echo (isset($task['completed']) && $task['completed']) ? 'Completed' : 'Pending'; ?>
                        </span>
                      <?php else: ?>
                        <span class="badge <?php echo (isset($task['completed']) && $task['completed']) ? 'ok' : 'pending'; ?>">
                          <?php echo (isset($task['completed']) && $task['completed']) ? 'Completed' : 'Pending'; ?>
                        </span>
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          <?php else: ?>
            <div class="no-tasks">No tasks scheduled for this day</div>
          <?php endif; ?>
        <?php endforeach; ?>
      <?php else: ?>
        <div class="no-tasks">
          No study plan generated yet. <a href="generate-plan.php">Generate your study plan first!</a>
        </div>
      <?php endif; ?>
    </section>

    <section class="card-1" style="margin-top:1.25em;">
      <h2 style="margin-top:0;">Upcoming Exams</h2>
      <p class="helper">Displays subject name, exam date, and progress based on completed chapters.</p>

      <table class="table">
        <thead>
          <tr>
            <th class="col-subject">Subject</th>
            <th class="col-date">Exam Date</th>
            <th class="col-status">Progress</th>
          </tr>
        </thead>
        <tbody>
          <?php if (count($upcoming_exams) > 0): ?>
            <?php foreach ($upcoming_exams as $exam): ?>
              <tr>
                <td class="td-clip" title="<?php echo htmlspecialchars($exam['SUBJECT_NAME']); ?>">
                  <?php echo htmlspecialchars($exam['SUBJECT_NAME']); ?>
                </td>
                <td class="col-date">
                  <time datetime="<?php echo htmlspecialchars($exam['EXAM_DATE']); ?>">
                    <?php echo htmlspecialchars($exam['EXAM_DATE']); ?>
                  </time>
                </td>
                <td>
                  <?php if (isset($exam_progress[$exam['SUBJECT_NAME']])): ?>
                    <?php $progress_data = $exam_progress[$exam['SUBJECT_NAME']]; ?>
                    <span class="progress-chip"><?php echo $progress_data['progress']; ?>%</span>
                    <div class="exam-progress-detail">
                      <?php echo $progress_data['completed']; ?>/<?php echo $progress_data['total']; ?> chapters
                    </div>
                  <?php else: ?>
                    <span class="progress-chip">0%</span>
                    <div class="exam-progress-detail">0/<?php echo !empty($exam['CHAPTERS']) ? count(explode(';', $exam['CHAPTERS'])) : 0; ?> chapters</div>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr>
              <td colspan="3" style="text-align: center;">No upcoming exams</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </section>
  </main>

  <footer>
    <div class="footer-container">
      <div class="logo">
        <div class="copyright">© 2025 PrepWise</div>
        <img src="PrepWiseLogo.png" alt="PrepWise logo" />
        <p class="textfooter">Smart study planner for students.</p>
      </div>

      <div class="social-media">
        <h3>Follow us</h3>
        <p><i>in</i> LinkedIn</p>
        <p><i>t</i> Twitter/X</p>
        <p><i>ig</i> Instagram</p>
      </div>

      <div class="contact-us">
        <h3>Contact</h3>
        <p><i>@</i> <a href="mailto:support@prepwise.app">support@prepwise.app</a></p>
        <p><i>☎</i> +966-555-000-000</p>
      </div>
    </div>
  </footer>

  <script>
    // Simple filter functionality
    document.getElementById('filterSubj')?.addEventListener('change', function() {
      const filterValue = this.value;
      const rows = document.querySelectorAll('.table tbody tr');
      
      rows.forEach(row => {
        const subjectName = row.querySelector('td:first-child').textContent.trim();
        if (filterValue === 'All Subjects' || subjectName === filterValue) {
          row.style.display = '';
        } else {
          row.style.display = 'none';
        }
      });
    });

    // Auto-save when checkbox is clicked in today's tasks
    document.querySelectorAll('form .chk').forEach(checkbox => {
      checkbox.addEventListener('change', function() {
        // Visual feedback
        const row = this.closest('tr');
        if (this.checked) {
          row.classList.add('task-completed');
        } else {
          row.classList.remove('task-completed');
        }
      });
    });
  </script>
</body>
</html>