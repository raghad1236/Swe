<?php
require_once 'config.php';

// Redirect to login if not authenticated
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header('Location: log.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

// Get the subject to edit from URL parameter
$subject_to_edit = $_GET['subject'] ?? '';

// If no subject specified, redirect to homepage
if (empty($subject_to_edit)) {
    header('Location: homepage.php');
    exit();
}

// Get the subject details
$stmt = $pdo->prepare("SELECT SUBJECT_NAME, EXAM_DATE, CHAPTERS FROM Exam WHERE SUBJECT_NAME = ? AND STUDENT_ID = ?");
$stmt->execute([$subject_to_edit, $user_id]);
$subject = $stmt->fetch(PDO::FETCH_ASSOC);

// If subject doesn't exist or doesn't belong to user, redirect
if (!$subject) {
    header('Location: homepage.php');
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_subject_name = trim($_POST['subject_name']);
    $exam_date = $_POST['exam_date'];
    
    // Validate inputs
    if (empty($new_subject_name) || empty($exam_date)) {
        $error = "Please fill in all fields";
    } else {
        try {
            // Update subject in database
            $stmt = $pdo->prepare("UPDATE Exam SET SUBJECT_NAME = ?, EXAM_DATE = ? WHERE SUBJECT_NAME = ? AND STUDENT_ID = ?");
            $stmt->execute([$new_subject_name, $exam_date, $subject_to_edit, $user_id]);
            
            $success = "Subject updated successfully!";
            
            // Update the current subject data
            $subject['SUBJECT_NAME'] = $new_subject_name;
            $subject['EXAM_DATE'] = $exam_date;
            $subject_to_edit = $new_subject_name;
            
        } catch (PDOException $e) {
            $error = "Error updating subject: " . $e->getMessage();
        }
    }
}

// Handle delete action
if (isset($_POST['delete_subject'])) {
    try {
        $stmt = $pdo->prepare("DELETE FROM Exam WHERE SUBJECT_NAME = ? AND STUDENT_ID = ?");
        $stmt->execute([$subject_to_edit, $user_id]);
        
        header('Location: homepage.php');
        exit();
    } catch (PDOException $e) {
        $error = "Error deleting subject: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Edit Subject • PrepWise</title>
  <link rel="stylesheet" href="style.css" />
  <style>
    .add-page { max-width: 800px; }
    .add-head { margin-bottom: 2em; }
    .add-card { background: var(--surface); padding: 2em; border-radius: var(--radius); box-shadow: var(--shadow); }
    .form-grid { display: grid; gap: 1.5em; }
    .form-row { margin-bottom: 1em; }
    .choice-set { border: 1px solid var(--border); padding: 1.5em; border-radius: var(--radius); }
    .current-subject-info { 
      background: var(--brand-ghost); 
      padding: 1em; 
      border-radius: 8px; 
      margin-bottom: 1.5em;
      border-left: 4px solid var(--brand);
    }
    .success-message {
      color: var(--ok-ink);
      background: var(--ok-bg);
      padding: 12px;
      border-radius: 8px;
      margin: 10px 0;
      border: 1px solid var(--ok-brd);
    }
    .error-message {
      color: var(--no-ink);
      background: var(--no-bg);
      padding: 12px;
      border-radius: 8px;
      margin: 10px 0;
      border: 1px solid var(--no-brd);
    }
    .btn.danger {
      background: #dc2626;
    }
    .btn.danger:hover {
      background: #b91c1c;
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(220, 38, 38, 0.4);
    }
    .btn.danger.ghost {
      background: transparent;
      color: #dc2626;
      border: 2px solid #dc2626;
    }
    .btn.danger.ghost:hover {
      background: #fef2f2;
    }
  </style>
</head>
<body>
  <header class="header">
    <div class="container">
      <div class="nav">
        <a class="brand" href="homepage.php">
          <img src="PrepWiseLogo.png" alt="PrepWise Logo" class="logo-img">
          <span>PrepWise</span>
        </a>
        <nav>
          <a href="homepage.php">Home</a>
          <a href="plan.php">Plan</a>
          <a href="Pomodoro.php">Pomodoro</a>
          <a href="Achievements.php">Achievements</a>
          <a href="Profile.php">Profile</a>
          <a href="logout.php">Logout</a>
        </nav>
      </div>
    </div>
  </header>

  <main class="container add-page">
    <div class="add-head">
      <h1>Edit Subject</h1>
      <p class="helper">Update the subject details below. Changes will be reflected across all pages.</p>
    </div>

    <section class="add-card">
      <!-- Current Subject Info -->
      <div class="current-subject-info">
        <h3 style="margin: 0 0 8px 0;">Currently Editing:</h3>
        <p style="margin: 0;">
          <strong>Subject:</strong> <?php echo htmlspecialchars($subject['SUBJECT_NAME']); ?><br>
          <strong>Exam Date:</strong> <?php echo htmlspecialchars($subject['EXAM_DATE']); ?><br>
          <strong>Chapters:</strong> <?php echo htmlspecialchars($subject['CHAPTERS']); ?>
        </p>
      </div>

      <?php if (!empty($success)): ?>
        <div class="success-message"><?php echo $success; ?></div>
      <?php endif; ?>

      <?php if (!empty($error)): ?>
        <div class="error-message"><?php echo $error; ?></div>
      <?php endif; ?>

      <form method="POST">
        <div class="form-grid">
          <!-- Subject details -->
          <fieldset class="choice-set">
            <legend>Subject Details</legend>
            <div class="form-row">
              <label for="subjectName">Subject Name</label>
              <input id="subjectName" class="input" type="text" name="subject_name" 
                     placeholder="e.g., Database" 
                     value="<?php echo htmlspecialchars($subject['SUBJECT_NAME']); ?>" 
                     required>
            </div>

            <div class="form-row">
              <label for="examDate">Exam Date</label>
              <input id="examDate" class="input" type="date" name="exam_date" 
                     value="<?php echo htmlspecialchars($subject['EXAM_DATE']); ?>" 
                     required>
            </div>

            <div class="form-row">
              <label>Current Chapters</label>
              <div style="padding: 12px; background: #f8f9fa; border-radius: 8px; border: 1px solid #e5e7eb;">
                <?php 
                $chapters = explode(';', $subject['CHAPTERS']);
                foreach ($chapters as $chapter): 
                  $chapter = trim($chapter);
                  if (!empty($chapter)):
                ?>
                  <div style="margin: 4px 0; padding: 4px 8px; background: white; border-radius: 4px; border: 1px solid #e5e7eb;">
                    <?php echo htmlspecialchars($chapter); ?>
                  </div>
                <?php 
                  endif;
                endforeach; 
                ?>
              </div>
              <p class="helper">To modify chapters, delete this subject and create a new one with updated chapters.</p>
            </div>
          </fieldset>
        </div>

        <!-- Buttons -->
        <div class="actions">
          <button type="submit" class="btn">Save Changes</button>
          <button type="button" class="btn danger ghost" onclick="confirmDelete()">Delete Subject</button>
          <a href="homepage.php" class="btn ghost">Cancel</a>
        </div>
      </form>

      <!-- Hidden delete form -->
      <form method="POST" id="deleteForm" style="display: none;">
        <input type="hidden" name="delete_subject" value="1">
      </form>
    </section>
  </main>

  <footer>
    <div class="footer-container">
      <div class="logo">
        <div class="copyright">© 2025 PrepWise</div>
        <img src="PrepWiseLogo.png" alt="PrepWise logo" />
        <p class="textfooter">Smart study planner for students.</p>
      </div>
      <div class="social-media">
        <h3>Follow us</h3>
        <p><i>in</i> LinkedIn</p>
        <p><i>t</i> Twitter/X</p>
        <p><i>ig</i> Instagram</p>
      </div>
      <div class="contact-us">
        <h3>Contact</h3>
        <p><i>@</i> <a href="mailto:support@prepwise.app">support@prepwise.app</a></p>
        <p><i>☎</i> +966-555-000-000</p>
      </div>
    </div>
  </footer>

  <script>
    function confirmDelete() {
      if (confirm('Are you sure you want to delete this subject? This action cannot be undone.')) {
        document.getElementById('deleteForm').submit();
      }
    }

    // Add real-time validation
    document.getElementById('subjectName').addEventListener('input', function() {
      if (this.value.trim().length < 2) {
        this.style.borderColor = '#dc2626';
      } else {
        this.style.borderColor = '#10b981';
      }
    });

    document.getElementById('examDate').addEventListener('change', function() {
      const selectedDate = new Date(this.value);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (selectedDate < today) {
        this.style.borderColor = '#dc2626';
        alert('Exam date cannot be in the past!');
      } else {
        this.style.borderColor = '#10b981';
      }
    });
  </script>
</body>
</html>