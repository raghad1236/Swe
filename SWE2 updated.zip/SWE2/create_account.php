<?php
require 'config.php';

// Database connection
$conn = new mysqli('localhost', 'root', 'root', 'prepwisedb');
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

$success = "";
$error = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email    = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (strlen($username) < 3) {
        $error = "Username must be at least 3 characters";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Enter a valid email";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters";
    } else {

        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $email_verified = 0;
        $profile_image  = "default.png";
        $role           = "user";

        $stmt = $conn->prepare("SELECT id FROM users WHERE username=? OR email=?");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error = "Username or Email already exists";
        } else {
            $stmt2 = $conn->prepare("
                INSERT INTO users (username, email, password, email_verified, profile_image, role)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt2->bind_param("sssiis", $username, $email, $hashed, $email_verified, $profile_image, $role);

            if ($stmt2->execute()) {
                $success = "Account created successfully. <a href='log.php'>Log in here</a>";
            } else {
                $error = "Error: " . $stmt2->error;
            }
            $stmt2->close();
        }

        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Create Account • PrepWise</title>
  <link rel="stylesheet" href="style.css" />
</head>

<body>

<!-- ================== HEADER (نفسه 100%) ================== -->
<header class="header">
  <div class="container">
    <div class="nav">
      <a class="brand" href="homepage.php">
        <img src="PrepWiseLogo.png" alt="PrepWise Logo" class="logo-img">
        <span>PrepWise</span>
      </a>

      <nav>
        <a href="homepage.php">Home</a>
        <a href="plan_display.php">Plan</a>
        <a href="Pomodoro.php">Pomodoro</a>
        <a href="Achievements.php">Achievements</a>
        <a href="Profile.php">Profile</a>
      </nav>
    </div>
  </div>
</header>

<!-- ================== PAGE CONTENT ================== -->
<div class="container" style="max-width:420px; margin-top:40px;">

    <h2 style="text-align:center; margin-bottom:25px;">Create Account</h2>

    <?php if (!empty($error)) { ?>
        <div style="background:#FEE2E2; color:#991B1B; padding:12px; border-radius:8px; margin-bottom:15px;">
            <?php echo $error; ?>
        </div>
    <?php } ?>

    <?php if (!empty($success)) { ?>
        <div style="background:#D1FAE5; color:#065F46; padding:12px; border-radius:8px; margin-bottom:15px;">
            <?php echo $success; ?>
        </div>
    <?php } ?>

    <form method="POST">
        <input type="text" name="username" placeholder="Username" required style="margin-bottom:12px;">
        <input type="email" name="email" placeholder="Email" required style="margin-bottom:12px;">
        <input type="password" name="password" placeholder="Password" required style="margin-bottom:12px;">
        <button type="submit" class="btn" style="width:100%;">Create Account</button>
    </form>

    <p style="text-align:center; margin-top:15px;">
        Already have an account? <a href="log.php">Log in</a>
    </p>
</div>

<!-- ================== FOOTER (نفسه 100%) ================== -->
<footer>
  <div class="footer-container">

      <div class="logo">
          <div class="copyright">© 2025 PrepWise</div>
          <img src="PrepWiseLogo.png" alt="PrepWise logo" />
          <p class="textfooter">Smart study planner for students.</p>
      </div>

      <div class="social-media">
          <h3>Follow us</h3>
          <p><i>in</i> LinkedIn</p>
          <p><i>t</i> Twitter/X</p>
          <p><i>ig</i> Instagram</p>
      </div>

      <div class="contact-us">
          <h3>Contact</h3>
          <p><i>@</i> <a href="mailto:support@prepwise.app">support@prepwise.app</a></p>
          <p><i>☎</i> +966-555-000-000</p>
      </div>

  </div>
</footer>

</body>
</html>