<?php
require_once 'config.php';

// Redirect to login if not authenticated
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header('Location: log.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Get the complete study plan for the user
$stmt = $pdo->prepare("SELECT * FROM daily_plan WHERE STUDENT_ID = ? ORDER BY PLAN_DATE ASC");
$stmt->execute([$user_id]);
$plans = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Function to get day name (Monday, Tuesday, ...)
function getDayName($date) {
    return date("l", strtotime($date));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Plan • PrepWise</title>
  <link rel="stylesheet" href="style.css" />
  
  <style>
    .day-block {
      padding: 20px;
      margin-bottom: 25px;
      background: var(--surface);
      border-radius: var(--radius);
      box-shadow: var(--shadow);
    }
    .day-block h2 {
      margin-top: 0;
      margin-bottom: 10px;
    }
    .task-card {
      padding: 12px;
      margin-bottom: 10px;
      border-radius: 8px;
      color: #fff;
    }
    .easy { background: #22c55e; }     /* أخضر */
    .medium { background: #eab308; }   /* أصفر */
    .hard { background: #ef4444; }     /* أحمر */
    .meta {
      font-size: 0.85em;
      opacity: 0.9;
    }
    .progress {
      margin-top: 10px;
      background: #eee;
      height: 10px;
      border-radius: 5px;
      overflow: hidden;
    }
    .progress-bar {
      height: 10px;
      background: var(--brand);
    }
    .no-plan {
      text-align: center;
      padding: 2em;
      background: #fff3cd;
      border-left: 4px solid #facc15;
      margin-top: 2em;
      border-radius: 6px;
    }
  </style>
</head>

<body>
  <header class="header">
    <div class="container">
      <div class="nav">
        <a class="brand" href="homepage.php">
          <img src="PrepWiseLogo.png" alt="PrepWise Logo" class="logo-img">
          <span>PrepWise</span>
        </a>
        <nav>
          <a href="homepage.php">Home</a>
          <a href="#" aria-current="page" style="font-weight:700;">Plan</a>
          <a href="Pomodoro.php">Pomodoro</a>
          <a href="Achievements.php">Achievements</a>
          <a href="Profile.php">Profile</a>
          <a href="logout.php">Logout</a>
        </nav>
      </div>
    </div>
  </header>

  <main class="container">
    <div class="card-1">
      <h1>Study Plan</h1>
      <p>Here is your full smart study plan based on exam dates and chapter difficulty.</p>
    </div>

    <!-- IF NO PLAN -->
    <?php if (count($plans) === 0): ?>
      <div class="no-plan">
        <h3>No plan generated yet</h3>
        <p>You can generate your study plan from the <strong>Homepage → Generate Plan</strong>.</p>
      </div>
    <?php endif; ?>

    <!-- DISPLAY PLAN -->
    <?php foreach ($plans as $plan): ?>
      <?php 
        $date = $plan['PLAN_DATE'];
        $dayName = getDayName($date);
        $tasks = json_decode($plan['TASKS'], true);
        $progress = intval($plan['PROGRESS_RATIO']);
      ?>

      <div class="day-block">
        <h2><?php echo $dayName . " — " . $date; ?></h2>

        <!-- Progress bar -->
        <div class="progress">
          <div class="progress-bar" style="width: <?php echo $progress; ?>%;"></div>
        </div>

        <!-- Tasks -->
        <?php if (!empty($tasks)): ?>
          <?php foreach ($tasks as $task): ?>
            <?php 
              $d = strtolower($task['difficulty']);
              if (!in_array($d, ['easy', 'medium', 'hard'])) $d = 'easy';
            ?>
            <div class="task-card <?php echo $d; ?>">
              <div class="chapter-title">
                <?php echo htmlspecialchars($task['subject']); ?> —
                <?php echo htmlspecialchars($task['chapter']); ?>
              </div>
              <div class="meta">
                📅 Exam: <?php echo htmlspecialchars($task['exam_date']); ?>
              </div>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <p style="color: var(--muted); font-style: italic;">No tasks scheduled for this day</p>
        <?php endif; ?>
      </div>

    <?php endforeach; ?>
  </main>

  <footer>
    <div class="footer-container">
      <div class="logo">
        <div class="copyright">© 2025 PrepWise</div>
        <img src="PrepWiseLogo.png" alt="PrepWise logo" />
        <p class="textfooter">Smart study planner for students.</p>
      </div>

      <div class="social-media">
        <h3>Follow us</h3>
        <p><i>in</i> LinkedIn</p>
        <p><i>t</i> Twitter/X</p>
        <p><i>ig</i> Instagram</p>
      </div>

      <div class="contact-us">
        <h3>Contact</h3>
        <p><i>@</i> <a href="mailto:support@prepwise.app">support@prepwise.app</a></p>
        <p><i>☎</i> +966-555-000-000</p>
      </div>
    </div>
  </footer>

</body>
</html>