<?php
require_once 'config.php';
require_once 'Auth.php';

// Check if the request is an AJAX POST request to save a session
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
    // ===========================================
    // AJAX SESSION SAVE LOGIC
    // ===========================================
    
    header('Content-Type: application/json');
    
    // Auth check for AJAX call
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
        echo json_encode(['success' => false, 'message' => 'User not authenticated.']);
        http_response_code(401); 
        exit();
    }

    $user_id = $_SESSION['user_id'];
    $data = json_decode(file_get_contents('php://input'), true);

    $start_time_str = $data['startTime'] ?? null; 
    $end_time_str = $data['endTime'] ?? null;     

    if (empty($start_time_str) || empty($end_time_str) || empty($user_id)) {
        echo json_encode(['success' => false, 'message' => 'Invalid session data: missing timestamps or user ID.']);
        http_response_code(400); 
        exit();
    }

    // Convert Unix timestamps (milliseconds) to MySQL datetime format
    $start_datetime = date('Y-m-d H:i:s', $start_time_str / 1000);
    $end_datetime = date('Y-m-d H:i:s', $end_time_str / 1000);
    $plan_date = date('Y-m-d', $start_time_str / 1000); 

    // Insert the session into the database using the provided table structure (pomodoro_session)
    try {
        $stmt = $pdo->prepare("
            INSERT INTO pomodoro_session (START_TIME, END_TIME, STUDENT_ID, PLAN_DATE) 
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$start_datetime, $end_datetime, $user_id, $plan_date]);

        // Fetch the new count
        $stmt_count = $pdo->prepare("SELECT COUNT(*) FROM pomodoro_session WHERE STUDENT_ID = ?");
        $stmt_count->execute([$user_id]);
        $new_session_count = $stmt_count->fetchColumn();
        
        // SUCCESS RESPONSE
        echo json_encode([
            'success' => true, 
            'message' => 'Session saved successfully!',
            'new_count' => $new_session_count
        ]);

    } catch (PDOException $e) {
        error_log("Database error saving Pomodoro session: " . $e->getMessage());
        
        // ERROR RESPONSE
        echo json_encode(['success' => false, 'message' => 'Database error during save.']);
        http_response_code(500);
    }
    
    // *** CRITICAL STEP: TERMINATE SCRIPT AFTER JSON OUTPUT ***
    exit(); 
}

// ===========================================
// PAGE RENDER LOGIC
// ===========================================
$user_id = Auth::getStudentId();
$user_name = Auth::getStudentName();

// Fetch the count of completed sessions for the user
$sessions_count = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM pomodoro_session WHERE STUDENT_ID = ?");
    $stmt->execute([$user_id]);
    $sessions_count = $stmt->fetchColumn();
} catch (PDOException $e) {
    error_log("Error fetching Pomodoro sessions: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pomodoro Timer • PrepWise</title>
    <style>
        body {
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(180deg, #0b1220, #18243a);
            color: #fff;
            margin: 0;
            padding: 0;
        }


        .header {
            background: #ffffff;
            border-bottom: 1px solid #eee;
            width: 100%;
        }
        .nav {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.875em 1.5em;
        }
        .brand {
            display: flex;
            align-items: center;
            gap: 0.75em;
            font-weight: 700;
            font-size: 1.25em;
            color: #4F46E5;
            text-decoration: none;
        }
        .brand svg {
            width: 1.75em;
            height: 1.75em;
        }
        .header nav a {
            text-decoration: none;
            color: #111827;
            padding: 0.5em 0.75em;
            border-radius: 10px;
            transition: 0.2s;
        }
        .header nav a:hover {
            background: #F3F4F6;
        }
        .header nav a[aria-current="page"] {
            background: #4F46E5;
            color: white;
        }

        /* ===================== Container ===================== */
        .pomodoro-container {
            max-width: 420px;
            margin: 100px auto;
            background-color: rgba(255, 255, 255, 0.05);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 25px rgba(0, 0, 0, 0.4);
            text-align: center;
        }

        /* ===================== Titles ===================== */
        .page-title {
            font-size: 26px;
            margin-bottom: 20px;
        }

        .section-title {
            font-size: 18px;
            margin-bottom: 10px;
            color: #cbd5e1;
        }

        /* ===================== Mode Buttons ===================== */
        .modes {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-bottom: 25px;
        }

        .modes input[type="radio"] {
            display: none;
        }

        .mode {
            background: transparent;
            border: 2px solid #3b82f6;
            color: #3b82f6;
            padding: 8px 16px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.2s ease;
        }

        .modes input[type="radio"]:checked + .mode {
            background: #3b82f6;
            color: #fff;
        }

        .mode:hover {
            background: rgba(59, 130, 246, 0.1);
        }


        .timer-display {
            font-size: 60px;
            font-weight: bold;
            letter-spacing: 3px;
            margin: 15px 0;
            color: #fff;
        }
        
        /* FIX: Ensure timer text is visible and dynamic */
        .minutes,
        .seconds {
            color: #fff; 
        }

        .timer-display .minutes::after,
        .timer-display .seconds::after,
        #mode50:checked ~ .timer-section .minutes::after {
            content: none !important; 
        }

        /* ===================== Buttons ===================== */
        .timer-buttons {
            display: flex;
            justify-content: center;
            gap: 10px;
            flex-wrap: wrap; 
        }

        .btn {
            padding: 10px 18px;
            font-size: 15px;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            color: #fff;
            transition: all 0.2s ease;
        }

        .start {
            background: #10b981;
        }
        .start:hover {
            background: #0d966e;
        }

        .pause {
            background: #f59e0b;
        }
        .pause:hover {
            background: #d97706;
        }

        .reset {
            background: #ef4444;
        }
        .reset:hover {
            background: #dc2626;
        }

        .finish { /* Style for the new finish button */
            background: #6366f1; /* Indigo color */
        }
        .finish:hover {
            background: #4f46e5;
        }


        .session-info {
            margin-top: 20px;
            font-size: 15px;
            color: #cbd5e1;
        }
        .session-info span {
            color: #3b82f6;
            font-weight: bold;
        }

        /* Footer Styles */
        footer {
            margin-top: auto;
            width: 100%;
        }
        .footer-container {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 1em;
            flex-wrap: wrap;
            padding: 2em;
            position: relative;
            width: 100%;
            color: #fff;
            background: linear-gradient(45deg, #0190b1, #6A5DFF);
        }
        .footer-container > div {
            min-width: 17.5em;
            padding: 0.5em;
        }
        .logo img {
            max-width: 20em;
            display: block;
            margin: 0 auto 1em;
        }
        .textfooter {
            font-size: 1em;
        }
        .copyright {
            position: absolute;
            top: 0.5em;
            left: 1em;
            font-size: 0.8em;
            color: #E6E6E6;
        }
        .social-media h3::after,
        .contact-us h3::after {
            content: "";
            display: block;
            width: 40px;
            height: 2px;
            background: rgba(255, 255, 255, 0.5);
            margin: 10px 0;
        }
        .social-media p,
        .contact-us p {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 8px 0;
        }
        .contact-us a {
            color: #fff;
        }
    </style>
</head>
<body>

    <header class="header">
        <div class="nav">
            <a href="homepage.php" class="brand">PrepWise</a>
            <nav>
                <a href="homepage.php">Home</a>
                <a href="plan.php">Plan</a>
                <a href="Pomodoro.php" aria-current="page">Pomodoro</a>
                <a href="Achievements.php">Achievements</a>
                <a href="Profile.php">Profile</a>
                <a href="logout.php">Logout</a>
            </nav>
        </div>
    </header>

    
    <main class="pomodoro-container">
        <h1 class="page-title">Pomodoro Timer</h1>
        <p style="color:#cbd5e1; font-size:14px;">Welcome, <?php echo htmlspecialchars($user_name); ?></p>

        <section class="mode-section">
            <h2 class="section-title">Select Mode</h2>
            <div class="modes">
                <input type="radio" name="mode" id="mode25" value="25" checked>
                <label for="mode25" class="mode">25 / 5</label>

                <input type="radio" name="mode" id="mode50" value="50">
                <label for="mode50" class="mode">50 / 10</label>
            </div>
        </section>

        <section class="timer-section">
            <div class="timer-display">
                <span class="minutes">25</span>
                <span class="colon">:</span>
                <span class="seconds">00</span>
            </div>

            <div class="timer-buttons">
                <button class="btn start">Start</button>
                <button class="btn pause" style="display: none;">Pause</button>
                <button class="btn finish" style="display: none;">Finish Session</button>
                <button class="btn reset">Reset</button>
            </div>
        </section>

        <section class="session-info">
            <p>Current Status: <span class="status">Ready (Study)</span></p>
            <p>Completed Sessions: <span class="sessions"><?php echo $sessions_count; ?></span></p>
        </section>
    </main>

    <footer>
        <div class="footer-container">
            <div class="logo">
                <img src="PrepWiseLogo.png" alt="PrepWise Logo"> 
            </div>

            <div class="textfooter">
                <p>Stay consistent, keep growing 🌱</p>
                <p>Manage your time and track your progress efficiently.</p>
            </div>

            <div class="social-media">
                <h3>Follow Us</h3>
                <p>📘 <a href="#">Facebook</a></p>
                <p>🐦 <a href="#">Twitter</a></p>
                <p>📸 <a href="#">Instagram</a></p>
            </div>

            <div class="contact-us">
                <h3>Contact Us</h3>
                <p>✉️ <a href="mailto:info@prepwise.com">info@prepwise.com</a></p>
                <p>📞 +966 555 123 456</p>
            </div>

            <p class="copyright">© 2025 PrepWise. All rights reserved.</p>
        </div>
    </footer>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const minutesDisplay = document.querySelector(".minutes");
            const secondsDisplay = document.querySelector(".seconds");
            const statusDisplay = document.querySelector(".status");
            const sessionsCountDisplay = document.querySelector(".sessions");
            const startButton = document.querySelector(".btn.start");
            const pauseButton = document.querySelector(".btn.pause");
            const finishButton = document.querySelector(".btn.finish"); 
            const resetButton = document.querySelector(".btn.reset");
            const modeRadios = document.querySelectorAll('input[name="mode"]');

            let isRunning = false;
            let timerInterval;
            let remainingTime = 0; // Time in seconds
            let currentMode = 25; // 25 minutes default study time
            let breakTime = 5; // Default short break
            let isStudySession = true;
            let sessionStartTime = null; // To store the starting timestamp (ms)

            const DEFAULT_TIMES = {
                25: { study: 25, break: 5 },
                50: { study: 50, break: 10 }
            };

            /**
             * Updates the timer display (minutes:seconds)
             */
            function updateDisplay() {
                const minutes = Math.floor(remainingTime / 60);
                const seconds = remainingTime % 60;
                
                minutesDisplay.textContent = String(minutes).padStart(2, '0');
                secondsDisplay.textContent = String(seconds).padStart(2, '0');
            }

            /**
             * Initializes or resets the timer based on the current mode and session type.
             */
            function resetTimer() {
                clearInterval(timerInterval);
                isRunning = false;
                
                const selectedModeValue = document.querySelector('input[name="mode"]:checked').value;
                currentMode = parseInt(selectedModeValue);

                isStudySession = true;
                sessionStartTime = null; 
                
                remainingTime = DEFAULT_TIMES[currentMode].study * 60;
                breakTime = DEFAULT_TIMES[currentMode].break;

                statusDisplay.textContent = "Ready (Study)";
                
                // Button visibility
                startButton.style.display = 'block';
                pauseButton.style.display = 'none';
                finishButton.style.display = 'none';
                
                updateDisplay();
            }

            /**
             * Saves a completed session to the database via AJAX call.
             * @param {number} startMs - Start time in milliseconds (Unix timestamp).
             * @param {number} endMs - End time in milliseconds (Unix timestamp).
             */
            async function saveSessionToDatabase(startMs, endMs) {
                if (!isStudySession) return; 
                
                try {
                    const response = await fetch('Pomodoro.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest' 
                        },
                        body: JSON.stringify({
                            startTime: startMs,
                            endTime: endMs
                        })
                    });

                    // Check if response is JSON and handle communication error gracefully
                    const responseText = await response.text();
                    let result;
                    try {
                        result = JSON.parse(responseText);
                    } catch (e) {
                        // This catches the communication error (e.g., if PHP outputted HTML or an error)
                        console.error("Non-JSON response received:", responseText);
                        // The alert will be triggered if parsing fails
                        alert("A communication error occurred while saving your session.");
                        return; 
                    }
                    
                    if (result.success) {
                        console.log(result.message);
                        // Only update the count if the save was successful
                        sessionsCountDisplay.textContent = result.new_count;
                    } else {
                        console.error("Failed to save session:", result.message);
                        alert("Error saving session: " + result.message);
                    }
                } catch (error) {
                    console.error("Network error during session save:", error);
                    alert("A network error occurred while saving your session.");
                }
            }
            
            /**
             * Handler when a session (Study or Break) finishes naturally or forcefully.
             * @param {boolean} forced - True if the session was ended by the 'Finish Session' button.
             */
            function endSession(forced) {
                clearInterval(timerInterval);
                isRunning = false;

                const now = Date.now();
                
                // Only save the session if it was a Study session that was running
                if (isStudySession && sessionStartTime) {
                    saveSessionToDatabase(sessionStartTime, now);
                }

                // Transition Logic
                if (isStudySession) {
                    remainingTime = breakTime * 60;
                    isStudySession = false;
                    statusDisplay.textContent = forced ? "Break Started (Forced End)" : "Time for a Break!";
                } else {
                    remainingTime = DEFAULT_TIMES[currentMode].study * 60;
                    isStudySession = true;
                    statusDisplay.textContent = "Time to Study!";
                    sessionStartTime = null; 
                }
                
                // Hide pause/finish buttons
                pauseButton.style.display = 'none';
                finishButton.style.display = 'none';
                startButton.style.display = 'block';

                updateDisplay();
            }


            /**
             * Starts the countdown timer.
             */
            function startTimer() {
                if (isRunning || remainingTime <= 0) return;

                isRunning = true;
                startButton.style.display = 'none';
                pauseButton.style.display = 'block';
                finishButton.style.display = isStudySession ? 'block' : 'none'; 

                if (isStudySession && sessionStartTime === null) {
                    sessionStartTime = Date.now(); 
                }

                timerInterval = setInterval(() => {
                    remainingTime--;
                    updateDisplay();

                    if (remainingTime <= 0) {
                        endSession(false);
                    }
                }, 1000);
            }

            /**
             * Pauses the countdown timer.
             */
            function pauseTimer() {
                if (!isRunning) return;

                clearInterval(timerInterval);
                isRunning = false;
                startButton.style.display = 'block';
                pauseButton.style.display = 'none';
                finishButton.style.display = 'none';
                statusDisplay.textContent = isStudySession ? "Paused (Study)" : "Paused (Break)";
            }
            
            /**
             * Stops the timer forcefully and records the session length.
             */
            function finishSessionHandler() {
                if (!isRunning || !isStudySession) return;
                
                if (confirm("Are you sure you want to finish the current study session early? The time recorded will be the actual time spent.")) {
                    endSession(true); 
                }
            }


            // --- Event Listeners ---
            startButton.addEventListener('click', startTimer);
            pauseButton.addEventListener('click', pauseTimer);
            finishButton.addEventListener('click', finishSessionHandler); 
            resetButton.addEventListener('click', resetTimer);

            // Mode change event listener
            modeRadios.forEach(radio => {
                radio.addEventListener('change', resetTimer);
            });

            // Initialize the timer on page load
            resetTimer();
        });
    </script>
</body>
</html>