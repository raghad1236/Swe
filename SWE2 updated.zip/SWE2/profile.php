<?php
require_once 'config.php';
require_once 'Auth.php';

// Get the authenticated user ID. This will redirect to log.php if not logged in.
$user_id = Auth::getStudentId();

$error = '';
$success = '';

// 1. Fetch current user data
$stmt = $pdo->prepare("SELECT STUDENT_NAME, STUDENT_EMAIL FROM User WHERE STUDENT_ID = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// If user somehow doesn't exist, redirect to log in
if (!$user) {
    header('Location: log.php');
    exit();
}

$full_name = $user['STUDENT_NAME'];
$email_address = $user['STUDENT_EMAIL'];

// 2. Handle form submission (Update logic)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_name = trim($_POST['name']);
    $new_email = trim($_POST['email']);
    $new_password = $_POST['password']; // This is for updating the password

    // Basic Validation
    if (empty($new_name) || empty($new_email)) {
        $error = "Full Name and Email are required fields.";
    } elseif (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } else {
        // Assume success unless a specific error occurs
        $update_query = "UPDATE User SET STUDENT_NAME = ?, STUDENT_EMAIL = ? WHERE STUDENT_ID = ?";
        $update_params = [$new_name, $new_email, $user_id];
        
        $password_updated = false;

        // If a new password is provided, include it in the update
        if (!empty($new_password)) {
            // Note: Your create_account.php uses password_hash(), but log.php does not. 
            // For security, you should hash it here, but I will use the non-hashed version 
            // from your log.php for functional consistency within the existing system.
            // **SECURITY WARNING: In a production system, you MUST hash the password here.**
            
            // For now, matching log.php's non-hashed approach:
            $update_query = "UPDATE User SET STUDENT_NAME = ?, STUDENT_EMAIL = ?, STUDENT_PASSWORD = ? WHERE STUDENT_ID = ?";
            $update_params = [$new_name, $new_email, $new_password, $user_id];
            $password_updated = true;
        }

        try {
            $stmt = $pdo->prepare($update_query);
            $stmt->execute($update_params);

            // Update local variables and session
            $full_name = $new_name;
            $email_address = $new_email;
            $_SESSION['user_name'] = $new_name;
            $_SESSION['user_email'] = $new_email;

            if ($password_updated) {
                $success = "Profile and password updated successfully!";
            } else {
                $success = "Profile information updated successfully!";
            }
            
            // Re-fetch to confirm no other changes
            $stmt = $pdo->prepare("SELECT STUDENT_NAME, STUDENT_EMAIL FROM User WHERE STUDENT_ID = ?");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            $full_name = $user['STUDENT_NAME'];
            $email_address = $user['STUDENT_EMAIL'];

        } catch (PDOException $e) {
            // In a real app, check for unique constraint violations (e.g., duplicate email)
            if ($e->getCode() == '23000') {
                $error = "Error: Email is already registered by another user.";
            } else {
                $error = "An error occurred during update: " . $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Profile Settings • PrepWise</title>
  <link rel="stylesheet" href="style.css">
  <style>
    /* Styles for the Profile Page - Adapted from your request CSS */
    .profile-container {
        max-width: 800px;
        margin: 3rem auto;
        background-color: var(--surface);
        padding: 2rem;
        border-radius: var(--radius);
        box-shadow: var(--shadow);
    }

    .profile-container h2 {
        text-align: center;
        color: var(--text);
        margin-bottom: 2rem;
    }

    .profile-section {
        margin-bottom: 2.5rem;
    }

    .profile-form label {
        display: block;
        margin-top: 1rem;
        font-weight: 600;
        color: var(--text);
    }

    .profile-form input {
        width: 100%;
        padding: 0.7rem;
        margin-top: 0.3rem;
        border: 1px solid var(--border);
        border-radius: 8px;
        font-size: 1em;
        background: #f8f9fa;
    }
    
    .profile-form input:focus {
        outline: none;
        border-color: var(--brand);
        background: #fff;
        box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
    }

    .save-btn {
        background-color: var(--brand);
        color: white;
        border: none;
        border-radius: 10px;
        padding: 0.8rem 1.5rem;
        margin-top: 1.5rem;
        cursor: pointer;
        transition: background 0.3s;
        font-weight: 600;
    }

    .save-btn:hover {
        background-color: var(--brand-2);
    }
    
    .alert {
        padding: 15px;
        margin-bottom: 1.5rem;
        border-radius: 8px;
        font-weight: 600;
        text-align: center;
    }

    .alert.success {
        background-color: var(--ok-bg);
        color: var(--ok-ink);
        border: 1px solid var(--ok-brd);
    }

    .alert.error {
        background-color: var(--no-bg);
        color: var(--no-ink);
        border: 1px solid var(--no-brd);
    }
  </style>
</head>
<body>
  <header class="header">
    <div class="container">
      <div class="nav">
        <a class="brand" href="homepage.php">
          <img src="PrepWiseLogo.png" alt="PrepWise Logo" class="logo-img">
          <span>PrepWise</span>
        </a>

        <nav>
          <a href="homepage.php">Home</a>
          <a href="plan.php">Plan</a>
          <a href="Pomodoro.php">Pomodoro</a>
          <a href="Achievements.php">Achievements</a>
          <a href="Profile.php" aria-current="page">Profile</a>
          <a href="logout.php">Logout</a>
        </nav>
      </div>
    </div>
  </header>

  <main class="container profile-container">
    <h2>👤 Profile Settings</h2>
    
    <?php if (!empty($error)): ?>
        <div class="alert error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <?php if (!empty($success)): ?>
        <div class="alert success"><?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>

    <section class="profile-section">
      <h3>Edit Profile Information</h3>
      <form class="profile-form" method="POST" action="">
        <label for="name">Full Name</label>
        <input type="text" id="name" name="name" placeholder="Enter your name" 
               value="<?php echo htmlspecialchars($full_name); ?>" required>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" placeholder="Enter your email" 
               value="<?php echo htmlspecialchars($email_address); ?>" required>

        <label for="password">New Password (leave blank to keep current)</label>
        <input type="password" id="password" name="password" placeholder="********">

        <button type="submit" class="save-btn">Save Changes</button>
      </form>
    </section>

  </main>

  <footer>
    <div class="footer-container">
      <div class="logo">
        <div class="copyright">© 2025 PrepWise</div>
        <img src="PrepWiseLogo.png" alt="PrepWise logo" />
        <p class="textfooter">Smart study planner for students.</p>
      </div>

      <div class="social-media">
        <h3>Follow us</h3>
        <p><i>in</i> LinkedIn</p>
        <p><i>t</i> Twitter/X</p>
        <p><i>ig</i> Instagram</p>
      </div>

      <div class="contact-us">
        <h3>Contact</h3>
        <p><i>@</i> <a href="mailto:support@prepwise.app">support@prepwise.app</a></p>
        <p><i>☎</i> +966-555-000-000</p>
      </div>
    </div>
  </footer>

  <script>
    // Simple client-side validation for password field
    document.querySelector('.profile-form').addEventListener('submit', function(e) {
        const passwordInput = document.getElementById('password');
        if (passwordInput.value.length > 0 && passwordInput.value.length < 6) {
            e.preventDefault();
            alert('Password must be at least 6 characters long.');
            passwordInput.focus();
        }
    });
  </script>
</body>
</html>